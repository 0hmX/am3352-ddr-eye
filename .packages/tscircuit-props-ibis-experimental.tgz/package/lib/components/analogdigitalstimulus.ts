import { ms } from "circuit-json"
import { expectTypesMatch } from "lib/typecheck"
import { z } from "zod"

export interface AnalogDigitalStimulusProps {
  name: string
  simulationRef: string
  /** Scoped physical output port whose IBIS logical input is controlled. */
  drives: string
  /** Raw numbers are milliseconds. */
  unitInterval: number | string
  /** Pattern start relative to simulation t=0. Raw numbers are milliseconds. */
  startTime: number | string
  /** Logical state before startTime, before optional inversion. */
  initialState: 0 | 1
  /** Complement initialState and pattern exactly once; independent of vendor polarity. */
  inverted?: boolean
  pattern: { type: "bits"; bits: string; repeat: boolean }
}

const finiteMilliseconds = ms.refine(Number.isFinite, "Time must be finite")
export const analogDigitalStimulusProps = z
  .object({
    name: z.string().trim().min(1),
    simulationRef: z.string().trim().min(1),
    drives: z.string().trim().min(1),
    unitInterval: finiteMilliseconds.refine(
      (time) => time > 0,
      "unitInterval must be positive",
    ),
    startTime: finiteMilliseconds.refine(
      (time) => time >= 0,
      "startTime must be nonnegative",
    ),
    initialState: z.union([z.literal(0), z.literal(1)]),
    inverted: z.boolean().optional(),
    pattern: z
      .object({
        type: z.literal("bits"),
        bits: z
          .string()
          .regex(/^[01]+$/, "bits must be a nonempty binary sequence"),
        repeat: z.boolean(),
      })
      .strict(),
  })
  .strict()

expectTypesMatch<
  AnalogDigitalStimulusProps,
  z.input<typeof analogDigitalStimulusProps>
>(true)
