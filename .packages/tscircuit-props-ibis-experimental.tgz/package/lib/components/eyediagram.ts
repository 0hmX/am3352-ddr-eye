import { expectTypesMatch } from "lib/typecheck"
import { z } from "zod"
import {
  analogEyeDiagramProps,
  type AnalogEyeDiagramProps,
} from "./analogeyediagram"

/** @deprecated Use analog.eyediagram with probeRef and simulationRef. Numeric legacy times remain seconds. */
export interface LegacyEyeDiagramProps {
  /** Stable name for this differential eye measurement. */
  name: string
  /** Selector identifying exactly one positive signal port. */
  positive: string
  /** Selector identifying exactly one negative signal port. */
  negative: string
  /** Bit interval. Numbers are seconds; strings require s/ms/us/ns/ps units. */
  unitInterval: number | string
  /** End of the transient simulation. Numbers are seconds. */
  duration: number | string
  /** Maximum transient timestep. Numbers are seconds. */
  timeStep: number | string
  /** Exclude startup before this time. Numbers are seconds. Defaults to 0s. */
  startTime?: number | string
}

const timeScale = { s: 1, ms: 1e-3, us: 1e-6, ns: 1e-9, ps: 1e-12 }
const timePattern =
  /^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?)\s*(s|ms|us|ns|ps)$/i
const seconds = z
  .union([z.number().finite(), z.string().trim().regex(timePattern)])
  .transform((time) => {
    if (typeof time === "number") return time
    const [, magnitude, unit] = time.match(timePattern)!
    return (
      Number(magnitude) *
      timeScale[unit!.toLowerCase() as keyof typeof timeScale]
    )
  })
  .refine(Number.isFinite, "Time must be finite")

const positiveSeconds = seconds.refine(
  (time) => time > 0,
  "Time must be positive",
)

export const legacyEyeDiagramProps = z
  .object({
    name: z.string().trim().min(1),
    positive: z.string().trim().min(1),
    negative: z.string().trim().min(1),
    unitInterval: positiveSeconds,
    duration: positiveSeconds,
    timeStep: positiveSeconds,
    startTime: seconds.default("0s"),
  })
  .strict()
  .superRefine((eye, context) => {
    const invalid = (path: keyof LegacyEyeDiagramProps, message: string) =>
      context.addIssue({ code: z.ZodIssueCode.custom, path: [path], message })
    if (eye.positive === eye.negative)
      invalid("negative", "EyeDiagram requires two distinct signal ports")
    if (
      eye.startTime < 0 ||
      eye.duration - eye.startTime < 2 * eye.unitInterval
    )
      invalid(
        "startTime",
        "Recording must include at least two unit intervals after a nonnegative startTime",
      )
    if (eye.timeStep > eye.unitInterval / 2)
      invalid("timeStep", "timeStep must not exceed half the unitInterval")
  })

expectTypesMatch<LegacyEyeDiagramProps, z.input<typeof legacyEyeDiagramProps>>(
  true,
)

export type EyeDiagramProps = AnalogEyeDiagramProps | LegacyEyeDiagramProps
export const eyeDiagramProps = z.union([
  analogEyeDiagramProps,
  legacyEyeDiagramProps,
])
