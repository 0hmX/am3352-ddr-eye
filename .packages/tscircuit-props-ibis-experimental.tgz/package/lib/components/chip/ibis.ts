import { z } from "zod"

/** Numeric clock times are seconds; string values must include a time unit. */
const clockTime = z.union([
  z.number().finite().positive(),
  z.string().regex(/^\s*\d+(?:\.\d+)?(?:e[+-]?\d+)?\s*(?:s|ms|us|ns|ps)\s*$/i),
])
const ibisClock = z.object({
  type: z.literal("clock"),
  period: clockTime,
  duration: clockTime,
  inverted: z.boolean().optional(),
})

/** Parent port names are keys; `pin` is the physical pin in the IBIS component. */
const ibisPinBinding = z.discriminatedUnion("mode", [
  z
    .object({
      pin: z.string().min(1),
      model: z.string().min(1).optional(),
      mode: z.literal("input"),
    })
    .strict(),
  z.object({
    pin: z.string().min(1),
    model: z.string().min(1).optional(),
    mode: z.literal("output"),
    stimulus: ibisClock,
  }),
])

/** Table-based IBIS import. Package policy and buffer supply bank are explicit. */
export const legacyIbisModelProps = z
  .object({
    source: z.string().min(1).optional(),
    sourceUrl: z.string().url().optional(),
    archivePath: z.string().min(1).optional(),
    sha256: z
      .string()
      .regex(/^[a-f0-9]{64}$/i)
      .optional(),
    component: z.string().min(1),
    pins: z
      .record(z.string(), ibisPinBinding)
      .refine(
        (pins) => Object.keys(pins).length > 0,
        "Select at least one IBIS pin",
      ),
    power: z.object({ vdd: z.string().min(1), vss: z.string().min(1) }),
    corner: z.enum(["typical", "minimum", "maximum"]).optional(),
    packageModel: z.enum(["none", "pin_rlc"]),
  })
  .superRefine((model, context) => {
    if (Boolean(model.source) === Boolean(model.sourceUrl))
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Provide exactly one of source or sourceUrl",
      })
    if (model.sourceUrl && !model.sha256)
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["sha256"],
        message: "URL imports require the SHA-256 of the extracted .ibs bytes",
      })
    if (model.power.vdd === model.power.vss)
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["power"],
        message: "VDD and VSS must map to different ports",
      })
  })

/** @deprecated Use IbisModelDefinition and per-experiment ibisPinStates/digitalstimulus. */
export type LegacyIbisModelProps = z.input<typeof legacyIbisModelProps>

const portName = z.string().trim().min(1)
const sha256 = z.string().regex(/^[a-f0-9]{64}$/i)
const archive = z
  .object({ member: portName, memberSha256: sha256.optional() })
  .strict()

/** source.sha256 covers raw URL/file bytes or UTF-8 content; archive.memberSha256 covers the extracted member. */
export const ibisSource = z.union([
  z
    .object({ url: z.string().url(), sha256, archive: archive.optional() })
    .strict(),
  z
    .object({
      file: portName,
      sha256: sha256.optional(),
      archive: archive.optional(),
    })
    .strict(),
  z.object({ content: z.string().min(1), sha256: sha256.optional() }).strict(),
])
export type IbisSource = z.input<typeof ibisSource>

export const ibisReferencePorts = z
  .object({
    pullup: portName.optional(),
    pulldown: portName.optional(),
    powerClamp: portName.optional(),
    groundClamp: portName.optional(),
    external: portName.optional(),
  })
  .strict()
export type IbisReferencePorts = z.input<typeof ibisReferencePorts>

/** Reusable electrical definition. All port names are local to the attached chip. */
export const ibisModelDefinitionProps = z
  .object({
    source: ibisSource,
    component: portName,
    /** Physical IBIS pin -> local TSX port, including reference rails. */
    pinMap: z
      .record(portName, portName)
      .refine(
        (pins) => Object.keys(pins).length > 0,
        "Map at least one physical IBIS pin",
      ),
    /** Physical signal pin -> selected model; the importer validates vendor membership. */
    modelSelections: z.record(portName, portName).optional(),
    references: z.record(portName, ibisReferencePorts).optional(),
    corner: z.enum(["typical", "minimum", "maximum"]),
    /** Preserve the vendor package or explicitly exclude it; unsupported vendor packages fail. */
    packagePolicy: z.enum(["vendor", "omit"]),
  })
  .strict()
export type IbisModelDefinition = z.input<typeof ibisModelDefinitionProps>

/** Canonical <ibismodel>; componentRef attaches to an existing scoped chip. */
export const ibismodelProps = ibisModelDefinitionProps.extend({
  componentRef: portName.optional(),
})
export type IbisModelElementProps = z.input<typeof ibismodelProps>
export interface IbisModelAttachmentProps extends IbisModelDefinition {
  componentRef: string
}

/** Legacy clock-bearing objects remain parseable; new definitions contain no stimulus. */
export const ibisModelProps = z.union([
  ibisModelDefinitionProps,
  legacyIbisModelProps,
])
export type IbisModelProps = z.input<typeof ibisModelProps>

export const ibisPinRunState = z.discriminatedUnion("mode", [
  z.object({ mode: z.literal("input") }).strict(),
  z.object({ mode: z.literal("output"), enabled: z.boolean() }).strict(),
])
export type IbisPinRunState = z.input<typeof ibisPinRunState>
