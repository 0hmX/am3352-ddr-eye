import { ms } from "circuit-json"
import { expectTypesMatch } from "lib/typecheck"
import { z } from "zod"

export interface AnalogEyeDiagramProps {
  name: string
  /** Scoped selector identifying exactly one voltageprobe. */
  probeRef: string
  /** Scoped selector identifying exactly one transient experiment. */
  simulationRef: string
  /** Positive bit/symbol interval. Raw numbers are milliseconds. */
  unitInterval: number | string
  /** Required fixed bit-boundary epoch relative to simulation t=0, in milliseconds. */
  timeOrigin: number | string
  /** Observation gate; defaults to the recorded waveform's start, in milliseconds. */
  startTime?: number | string
  /** Observation gate; defaults to the recorded waveform's end, in milliseconds. */
  endTime?: number | string
}

const finiteMilliseconds = ms.refine(Number.isFinite, "Time must be finite")
export const analogEyeDiagramProps = z
  .object({
    name: z.string().trim().min(1),
    probeRef: z.string().trim().min(1),
    simulationRef: z.string().trim().min(1),
    unitInterval: finiteMilliseconds.refine(
      (time) => time > 0,
      "unitInterval must be positive",
    ),
    timeOrigin: finiteMilliseconds,
    startTime: finiteMilliseconds
      .refine((time) => time >= 0, "startTime must be nonnegative")
      .optional(),
    endTime: finiteMilliseconds
      .refine((time) => time >= 0, "endTime must be nonnegative")
      .optional(),
  })
  .strict()
  .superRefine((eye, context) => {
    if (
      eye.startTime !== undefined &&
      eye.endTime !== undefined &&
      eye.startTime >= eye.endTime
    )
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["endTime"],
        message: "endTime must follow startTime",
      })
  })

expectTypesMatch<AnalogEyeDiagramProps, z.input<typeof analogEyeDiagramProps>>(
  true,
)
