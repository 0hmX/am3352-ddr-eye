import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type RouteReservedViaBusesParams, type ReservedViaBusesProgress } from "./route-reserved-via-buses";
import type { FanoutRoutePlan, Point2D, PreparedBus } from "./types";
interface SourceRules {
    srj: SimpleRouteJson;
    buses: readonly PreparedBus[];
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
}
export interface SourceOriginReservations {
    fixedViaPointsByConnectionIndex: Map<number, Point2D>;
    sourceEscapePaths: Map<number, readonly Point2D[]>;
    sourcePlans: FanoutRoutePlan[];
}
/** Reserve every source before freeing a selected boundary group jointly. */
export declare function prepareSourceOriginReservations(params: SourceRules): SourceOriginReservations | null;
export interface SourceOriginBusRoutingParams extends RouteReservedViaBusesParams {
    /** Reconnect shorter source routes to successively narrower retained exit tails. */
    cleanupRetainedBoundaryTails?: boolean;
    /** Bound speculative first-via searches independently of later cleanup. */
    maximumSourceIterations?: number;
}
interface SourceOriginResult extends SourceOriginReservations {
    /** Every connection of the selected original buses, still awaiting length matching. */
    plans: FanoutRoutePlan[];
}
/**
 * Choose first vias collectively, then shorten a bounded set of complete lanes.
 * Other sources and already routed copper remain immutable. Each replacement
 * preserves the original endpoint and cannot increase its complete bus's skew.
 */
export declare function routeSourceOriginBusesSteps(params: SourceOriginBusRoutingParams): Generator<ReservedViaBusesProgress, SourceOriginResult | null, unknown>;
/** Several smaller buses can impose the same constrained-layer ordering. */
export declare function hasSplitFixedWideLayer(buses: readonly PreparedBus[]): boolean;
/** Bias a whole-package traverse onto the constrained target layer. */
export declare function hasOppositeFixedWideBus(buses: readonly PreparedBus[]): boolean;
/** Dense fields with a wide, fixed-layer group need joint first-via ordering. */
export declare function shouldUseSourceOriginRouting(buses: readonly PreparedBus[], allowBlindAndBuriedVias: boolean): boolean;
export {};
