import { type RouteBusParams } from "./route-bus";
import type { PeripheralSourceEscape } from "./route-peripheral-source-escapes";
import { type RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { Bounds, FanoutRoutePlan } from "./types";
/** Route a right-edge bus through a peripheral crossbar on its two allowed layers. */
export declare function routeLeftCrossbarBusSteps(params: RouteBusParams & {
    sourceEscapes: readonly PeripheralSourceEscape[];
    sourceBoundary: Bounds;
}): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[] | null, void>;
