export interface UniformNeighborGrid {
    planeSize: number;
    cellCenterX: Float64Array;
    cellCenterY: Float64Array;
    cellMinX: Float64Array;
    cellMaxX: Float64Array;
    cellMinY: Float64Array;
    cellMaxY: Float64Array;
    neighborOffset: Int32Array;
    neighborIds: Int32Array;
    neighborCosts: Float32Array;
}
/**
 * Add one-cell 45-degree edges without changing existing cardinal/seam links.
 * Clipped or unequal cells retain their original adjacency. Callers must apply
 * their existing exact segment, dynamic copper and final route validation.
 */
export declare function addDiagonalGridNeighbors(grid: UniformNeighborGrid): Pick<UniformNeighborGrid, "neighborOffset" | "neighborIds" | "neighborCosts">;
