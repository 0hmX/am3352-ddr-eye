import { type FanoutPlanCornerNormalizationParams } from "./normalize-fanout-plan-corners";
import type { FanoutRoutePlan, PreparedBus } from "./types";
interface Params extends FanoutPlanCornerNormalizationParams {
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
}
/**
 * Private geometric repair, before original bus/pair length matching. Replace
 * only source prefixes; every first via and all subsequent copper stay fixed.
 * At most 384 source proposals and 64 local fold shortcuts per affected plan;
 * failure rolls back the whole set.
 */
export declare function repairSourcePadReentries(params: Params): FanoutRoutePlan[] | null;
export {};
