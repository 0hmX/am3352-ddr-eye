import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutRoutePlan, PreparedBus } from "./types";
/**
 * Reassign only caller-declared, unfinished direct signal dogbones around a
 * proposed tuning shape. Complete copper and every plane reservation stay
 * immutable. The caller must still match its complete current bus before
 * committing the returned source paths and first vias.
 */
export declare function rematchUnroutedSourceDogbones(params: {
    inputSrj: SimpleRouteJson;
    plans: readonly FanoutRoutePlan[];
    unroutedSourceBuses: readonly PreparedBus[];
    clearance: number;
}): FanoutRoutePlan[] | null;
