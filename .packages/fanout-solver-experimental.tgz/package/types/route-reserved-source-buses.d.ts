import type { Bounds, FanoutRoutePlan, PreparedBus } from "./types";
import type { PeripheralSourceEscape } from "./route-peripheral-source-escapes";
import { type RouteBusAlternativesProgress, type RouteBusParams } from "./route-bus";
export interface RouteReservedSourceBusesParams extends Omit<RouteBusParams, "bus" | "targetLayer" | "acceptedPlans"> {
    buses: readonly PreparedBus[];
    sourceEscapes: readonly PeripheralSourceEscape[];
    initialPlans: readonly FanoutRoutePlan[];
    targetLayerByBusId?: ReadonlyMap<string, string>;
    sourceBoundary?: Bounds;
}
/** Finish buses while preserving every already matched source escape and via. */
export declare function routeReservedSourceBusesSteps(params: RouteReservedSourceBusesParams): Generator<RouteBusAlternativesProgress, FanoutRoutePlan[] | null, void>;
