import type { Point2D, PreparedBus } from "./types";
/**
 * A peripheral source field turning into an exit interval narrower than its
 * via envelope benefits from choosing the first vias together. Restrict this
 * choice to competing wide buses that also permit an internal transit layer;
 * narrow pairs and ordinary, separated boundary intervals keep their routing.
 */
export declare function hasCompressedExitConvergence(params: {
    buses: readonly PreparedBus[];
    targetLayer: string;
    exits: ReadonlyMap<number, Point2D>;
    layerNames: readonly string[];
    viaDiameter: number;
    clearance: number;
}): boolean;
