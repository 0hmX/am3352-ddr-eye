import type { Point2D, PreparedBus } from "./types";
interface Params {
    buses: readonly PreparedBus[];
    exits: ReadonlyMap<number, Point2D>;
    /** Bounds the product of the original layer-sequence lengths. */
    maximumSearchStates?: number;
}
/** Different original target layers may interleave; each layer retains its lane order. */
export declare function boundaryTargetsPreserveLayerOrder(bus: PreparedBus, exits: ReadonlyMap<number, Point2D>): boolean;
/** Select a legal merge with fewer source-order inversions, retaining every packed track. */
export declare function mergeLayeredBoundaryTargets(params: Params): Map<number, Point2D>;
export {};
