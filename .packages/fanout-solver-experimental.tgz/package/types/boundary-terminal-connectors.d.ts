import type { Bounds, FanoutEdge, FanoutRoutePlan, Point2D, RoutedSegment } from "./types";
export interface BoundaryTerminalConnector {
    connectionName: string;
    edge: FanoutEdge;
    layer: string;
    exit: Point2D;
    goal: Point2D;
}
/** Preserve the caller's exact boundary target; only the native goal moves. */
export declare function createBoundaryTerminalConnector(params: {
    connectionName: string;
    edge: FanoutEdge;
    layer: string;
    exit: Point2D;
    bounds: Bounds;
    approachLength: number;
}): BoundaryTerminalConnector;
/** Preserve a perpendicular tail, aligning with its lane through one 45-degree bend. */
export declare function getBoundaryTerminalEntry(start: Point2D, connector: BoundaryTerminalConnector): Point2D[] | null;
interface NeighborGrid {
    planeSize: number;
    neighborOffset: Int32Array;
    neighborIds: Int32Array;
    neighborCosts: Float32Array;
    cellCenterX: Float64Array;
    cellCenterY: Float64Array;
}
export interface TerminalConnectorRegion extends Bounds {
}
/** The actual emitted path and the first appended entry segment, in path order. */
export interface BoundaryTerminalSplice {
    rawSegments: readonly RoutedSegment[];
    firstEntrySegmentIndex: number;
}
/** Check only actual entry copper, against every retained arm and physical hole. */
export declare function boundaryTerminalPlanIsSelfClear(params: {
    plan: FanoutRoutePlan;
    splice: BoundaryTerminalSplice;
    maximumJoinLength: number;
    clearance: number;
}): boolean;
/**
 * Repair the emitted entry's own clearance with the other axis/45 ordering or
 * by replacing at most four pitches of its final grid walk. Search occupancy
 * stays unchanged; check every replacement against all retained copper before
 * the caller normalizes and validates the complete bus.
 */
export declare function repairBoundaryTerminalEntries(params: {
    plans: readonly FanoutRoutePlan[];
    splices: ReadonlyMap<string, BoundaryTerminalSplice>;
    connectors: ReadonlyMap<string, BoundaryTerminalConnector>;
    clearance: number;
    segmentIsClear: (segment: RoutedSegment, connectionName: string) => boolean;
}): {
    plans: FanoutRoutePlan[];
    splices: Map<string, BoundaryTerminalSplice>;
} | null;
/**
 * Add directed two-hop links only. The caller must restrict each added edge to
 * its active terminal/layer and check every emitted entry segment dynamically.
 */
export declare function addBoundaryTerminalNeighbors(params: {
    grid: NeighborGrid;
    terminals: readonly {
        connector: BoundaryTerminalConnector;
        cellId: number;
    }[];
    segmentIsClear: (a: Point2D, b: Point2D, connector: BoundaryTerminalConnector) => boolean;
    margin: number;
}): Pick<NeighborGrid, "neighborOffset" | "neighborIds" | "neighborCosts"> & {
    extendedEdges: ReadonlySet<string>;
    regions: readonly TerminalConnectorRegion[];
};
export type TerminalCopperPoint = Point2D & {
    z: number;
};
export interface TerminalCopperRoute {
    connectionName: string;
    route: TerminalCopperPoint[];
    vias: Point2D[];
}
/** Restore the exact public exit without relocating an end-cell through via. */
export declare function appendBoundaryTerminalApproach(route: TerminalCopperRoute, connector: BoundaryTerminalConnector, endCellCenter: Point2D): TerminalCopperRoute;
/**
 * Exact negotiated copper near terminal entries. Native cell occupancy alone
 * does not describe a bend between cells. Invalidate after BOTH finalization
 * and ripping; owners are returned to the caller's existing native rip chain.
 */
export declare class BoundaryTerminalCopper {
    private params;
    private dirty;
    private buckets;
    private readonly cellSize;
    private readonly padding;
    constructor(params: {
        regions: readonly TerminalConnectorRegion[];
        traceWidth: number;
        clearance: number;
        viaDiameter: number;
        getRoutes: () => readonly TerminalCopperRoute[];
    });
    invalidate(): void;
    private intersects;
    private cells;
    private refresh;
    private nearby;
    blockingSegmentOwners(owner: string, points: readonly Point2D[], z: number): Set<string>;
    /** Always query the actual cell-center barrel, even for a zero-length entry. */
    blockingViaOwners(owner: string, center: Point2D): Set<string>;
}
export {};
