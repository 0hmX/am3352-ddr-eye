import type { FanoutRoutePlan } from "./types";
export interface SourcePadReentry {
    segmentIndex: number;
    kind: "outline" | "copper" | "clearance";
}
/** Once a route leaves its own pad, that pad is no longer an escape exemption. */
export declare function getSourcePadReentries(plan: FanoutRoutePlan, clearance: number): SourcePadReentry[];
