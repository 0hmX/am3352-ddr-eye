import type { PreparedBus } from "./types";
type AdaptiveDensePlaneBus = Pick<PreparedBus, "componentBounds" | "componentId" | "connections" | "exitEdge" | "termination">;
/**
 * Detect a dense memory-controller field that must turn across the component
 * to reach a perpendicular shared breakout edge. This is based on topology
 * and relative geometry, so rotating or mirroring the circuit does not change
 * the choice.
 */
export declare function shouldUseAdaptiveDensePlaneRouting(buses: readonly AdaptiveDensePlaneBus[], allowBlindAndBuriedVias: boolean): boolean;
export {};
