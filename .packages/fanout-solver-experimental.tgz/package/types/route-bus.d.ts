import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type RouteViaMinimalWindingProgress, type ViaMinimalWindingReservedVia } from "./route-via-minimal-winding";
import type { Bounds, FanoutDirection, FanoutRoutePlan, Point2D, PreparedBus, PreparedConnection } from "./types";
export type RouteBusStaticClearanceCache = Map<string, boolean>;
export interface RouteBusParams {
    srj: SimpleRouteJson;
    bus: PreparedBus;
    targetLayer: string;
    acceptedPlans: FanoutRoutePlan[];
    layerNames: string[];
    traceWidth: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    clearance: number;
    compactBusTracks: boolean;
    allowBlindAndBuriedVias?: boolean;
    allowSameNetMerges?: boolean;
    staticClearanceCache?: RouteBusStaticClearanceCache;
    blockingBusCounts?: Map<string, number>;
    rejectedViaMinimalCandidates?: FanoutRoutePlan[][];
    stopAfterFirstRejectedViaMinimalCandidate?: boolean;
    fixedViaPointsByConnectionIndex?: ReadonlyMap<number, Point2D>;
    /** Complete boundary tracks for this bus, keyed by stable connection identity. */
    fixedBoundaryTracksByConnectionIndex?: ReadonlyMap<number, number>;
    /** Actual copper before the first via for previously reserved source escapes. */
    sourceEscapePaths?: ReadonlyMap<number, readonly Point2D[]>;
    /** Exact winding spacing for staged narrow-channel routing. */
    windingGridStep?: number;
    reservedVias?: readonly ViaMinimalWindingReservedVia[];
    /** Provisional site preferences; successful callers must rematch future vias. */
    softReservedVias?: readonly ViaMinimalWindingReservedVia[];
    viaMinimalOnly?: boolean;
    /** Permit a singleton or pair to move provisional vias near the boundary. */
    allowBoundarySideViaFallback?: boolean;
    /** Reserve corner tuning space when selecting a boundary-side via. */
    preferCornerBoundaryVia?: boolean;
    /** Retry blocked winding terminals ahead of already-routed terminals. */
    adaptiveWindingRouteOrder?: boolean;
    /** Preserve pad-lattice channels in the automatic dense routing path. */
    alignWindingGridToPads?: boolean;
    /** Bounds the final fixed-via winding fallback after ordered attempts. */
    fixedViaFallbackRouteOrderAttempts?: number;
    /** Retry caller-fixed sites while preserving future exit gaps during recovery. */
    allowFixedViaReservedExitFallback?: boolean;
    /** Skip this many otherwise-clear plane escapes when enumerating alternatives. */
    planeCandidateSkipCount?: number;
    /** Dense corner-band phase that preserves existing lane centers when leading lanes are prepended. */
    cornerBandTargetTrackOffset?: number;
    /** Fixed first corner slot, independent of the order in which buses route. */
    cornerExitLaneOffset?: number;
    /** Optional search weighting for winding; does not change route validation. */
    windingHeuristicWeight?: number;
    /** Permit contact with the shared boundary only at the declared exit. */
    forbidEarlyExitBoundaryContact?: boolean;
}
export interface RouteBusAlternativesProgress {
    phase: "via-minimal-winding";
    busId: string;
    targetLayer: string;
    winding: RouteViaMinimalWindingProgress;
}
export declare function getBoundaryTargetTrack(params: {
    bus: PreparedBus;
    connection: PreparedConnection;
    boundaryDirection: FanoutDirection;
    traceWidth?: number;
    clearance?: number;
    layerNames?: readonly string[];
    targetLayer?: string;
    windingOrderIndex?: number;
    allowLayerInterleaving?: boolean;
    fixedBoundaryTracksByConnectionIndex?: ReadonlyMap<number, number>;
}): number;
export declare function getCornerTargetTrack(params: {
    bus: PreparedBus;
    connection: PreparedConnection;
    cornerExitLaneOffset: number;
    traceWidth: number;
    viaDiameter: number;
    clearance: number;
    layerNames: readonly string[];
    targetLayer: string;
    windingOrderIndex?: number;
    cornerBandTargetTrackOffset?: number;
    fixedBoundaryTracksByConnectionIndex?: ReadonlyMap<number, number>;
}): number;
export declare function fanoutPlansAreMutuallyClear(params: {
    plans: readonly FanoutRoutePlan[];
    srj: SimpleRouteJson;
    clearance: number;
    allowSameNetMerges?: boolean;
}): boolean;
/**
 * Validate a complete set of fanout plans against the source SRJ and against
 * one another. This is intentionally separate from route search so every
 * route-producing strategy can share the same final safety invariant.
 */
export declare function fanoutPlansAreClear(params: {
    plans: readonly FanoutRoutePlan[];
    srj: SimpleRouteJson;
    sharedBoundary: Bounds;
    clearance: number;
    allowBlindAndBuriedVias?: boolean;
    allowSameNetMerges?: boolean;
    /** Share copper between declared plane drops without merging signal branches. */
    allowSameNetPlaneMerges?: boolean;
}): boolean;
/** Reuse clearance results while a caller replaces immutable route plans.
 * Keep one validator per fixed SRJ, boundary and rule set. A replacement plan
 * is checked against every other plan; no changed copper inherits cached checks.
 */
export declare function createFanoutPlanClearanceValidator(params: Omit<Parameters<typeof fanoutPlansAreClear>[0], "plans">): ((plans: readonly FanoutRoutePlan[]) => boolean) & {
    mutuallyClear(plans: readonly FanoutRoutePlan[]): boolean;
};
export declare function routeBusAlternativesSteps(params: RouteBusParams, maxAlternatives?: number, includeVisualization?: boolean): Generator<RouteBusAlternativesProgress, FanoutRoutePlan[][], void>;
export declare function routeBusAlternatives(params: RouteBusParams, maxAlternatives?: number): FanoutRoutePlan[][];
export declare function routeBus(params: RouteBusParams): FanoutRoutePlan[] | null;
