import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type ReservedViaBusesProgress } from "./route-reserved-via-buses";
import type { FanoutRoutePlan, PreparedBus } from "./types";
interface RepairWideSourceLengthsParams {
    inputSrj: SimpleRouteJson;
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    completedBuses: readonly PreparedBus[];
    selectedBusIds: ReadonlySet<string>;
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
}
type WideSourceGeometry = Pick<RepairWideSourceLengthsParams, "plans" | "completedBuses" | "selectedBusIds">;
/** Cheap eligibility check, before consuming a group's single cleanup attempt. */
export declare function hasOverlongWideSourcePrefix(params: WideSourceGeometry): boolean;
/**
 * A source prefix can itself exceed the complete bus's length allowance.
 * Shorten that retained copper, distribute the remaining tuning, then try one
 * new first via when only one lane remains short. Everything stays provisional
 * until the entire completed group matches and every original source clears.
 */
export declare function repairWideSourceLengthsSteps(params: RepairWideSourceLengthsParams): Generator<ReservedViaBusesProgress, FanoutRoutePlan[] | null>;
export {};
