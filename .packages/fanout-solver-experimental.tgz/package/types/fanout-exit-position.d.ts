import type { FanoutExitPosition, FanoutExitPositionConfig } from "./types";
/** Resolves a canonical exit position into the solver's orthogonal fields. */
export declare function getFanoutExitPositionConfig(exitPosition: FanoutExitPosition): Readonly<FanoutExitPositionConfig>;
