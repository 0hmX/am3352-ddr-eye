import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Point2D } from "./types";
type Obstacle = SimpleRouteJson["obstacles"][number];
/** The source-pad exception applies only to an outward edge and its owner. */
export declare function getOutwardSourcePadOwner(start: Point2D, end: Point2D, layer: string, traceWidth: number, clearance: number, obstacle: Obstacle, source: {
    connectionName: string;
    sourcePoint: Point2D;
} | undefined): string | undefined;
export {};
