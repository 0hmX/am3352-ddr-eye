import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { Bounds, FanoutRoutePlan, PreparedBus } from "./types";
import type { PeripheralSourceEscape } from "./route-peripheral-source-escapes";
export type { PeripheralSourceEscape } from "./route-peripheral-source-escapes";
/** Join ordered inner-layer source escapes to nested perimeter lanes. */
export declare function routeStagedPerimeterBusSteps(params: {
    srj: SimpleRouteJson;
    bus: PreparedBus;
    targetLayer: string;
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    sourceBoundary: Bounds;
    sourceEscapes: readonly PeripheralSourceEscape[];
    remoteConnectionIndices: ReadonlySet<number>;
}): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[] | null, void>;
