interface ViaOccupantRouter {
    _viaOccs: number[];
    usedCellsFlat?: Int32Array;
    sharedCellsFlat?: (number[] | undefined)[];
    fillViaOccupants(cellId: number, activeConnection: number): void;
    pushFlatOccupants(flatIndex: number, activeConnection: number, occupants: number[]): void;
}
/**
 * A router's grid, via diameter and layer count stay fixed during search.
 * Record the native neighborhood traversal once per cell, preserving its exact
 * order. Read current occupancy and ownership through the native routine on
 * every visit, including after rip-ups. Never cache the occupants themselves.
 */
export declare function cacheViaOccupantNeighborhoods(router: ViaOccupantRouter): void;
export {};
