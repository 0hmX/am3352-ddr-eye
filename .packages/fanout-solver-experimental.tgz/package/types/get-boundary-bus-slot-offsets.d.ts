import type { PreparedBus } from "./types";
/** Reserve intact bus intervals before choosing which bus to route first. */
export declare function getBoundaryBusSlotOffsets(buses: readonly PreparedBus[]): Map<string, number>;
