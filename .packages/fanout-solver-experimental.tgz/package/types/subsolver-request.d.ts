import { BaseSolver } from "@tscircuit/solver-utils";
export interface SubsolverRequest {
    type: "subsolver";
    solver: BaseSolver;
}
export declare function isSubsolverRequest(request: unknown): request is SubsolverRequest;
