/** A static grid edge is clear, blocked, or usable only by the named owner. */
export type StaticEdgeClearance = boolean | string;
/**
 * Store directed grid edges in the native router's immutable neighbor order.
 * Each layer also has one slot per cell for a via move. Non-neighbor edges
 * retain their complete directed key in a Map. Terminal connectors bypass
 * caching because their physical endpoints depend on the active connection.
 */
export declare class StaticEdgeClearanceCache {
    private readonly planeSize;
    private readonly neighborOffset;
    private readonly neighborIds;
    private readonly classes;
    private readonly layerStride;
    private readonly values;
    private readonly ownerIds;
    private readonly overflow;
    constructor(planeSize: number, layerCount: number, neighborOffset: Int32Array, neighborIds: Int32Array);
    private getSlot;
    get(origin: number, target: number, usesTerminal?: boolean): StaticEdgeClearance | undefined;
    set(origin: number, target: number, value: StaticEdgeClearance, usesTerminal?: boolean): void;
}
