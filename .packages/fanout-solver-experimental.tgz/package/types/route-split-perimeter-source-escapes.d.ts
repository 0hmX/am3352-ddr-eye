import type { PeripheralSourceEscape, PeripheralSourceEscapeParams } from "./route-peripheral-source-escapes";
import type { Bounds, Point2D } from "./types";
export interface SplitPerimeterSources {
    sourceEscapes: PeripheralSourceEscape[];
    sourceBoundary: Bounds;
    remoteConnectionIndices: Set<number>;
    bottomRemoteConnectionIndices: Set<number>;
    lowerConnectionIndices: number[];
    viaPointsByConnectionIndex: Map<number, Point2D>;
}
export declare function chamferSplitPerimeter(points: readonly Point2D[], width: number): Point2D[];
/** A source-layer split allows a reversed lower group to use the opposite perimeter. */
export declare function routeSplitPerimeterSourceEscapesSteps(params: PeripheralSourceEscapeParams): Generator<void, SplitPerimeterSources | null, unknown>;
