import type { Point2D } from "./types";
/** Dense crossings predict long detours when a whole group shares one layer. */
export declare function sourceTransitHasMajorityCrossings(paths: readonly {
    source: Point2D;
    target: Point2D;
}[]): boolean;
