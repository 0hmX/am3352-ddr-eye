import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutRoutePlan, PreparedBus, RoutedSegment } from "./types";
export interface FanoutPlanCornerNormalizationParams {
    inputSrj: SimpleRouteJson;
    layerNames: string[];
    traceWidth: number;
    clearance: number;
}
export interface FinalFanoutPlanNormalizationParams extends FanoutPlanCornerNormalizationParams {
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    viaDiameter: number;
    viaHoleDiameter: number;
    /** Repair source-only plane drops with no separate endpoint copper. */
    repairPlaneSourceCorners?: boolean;
    /** Repair signal source prefixes while retaining every via and target segment. */
    repairSignalSourceCorners?: boolean;
    /** Restore original bus/pair limits after boundary or corner cleanup. */
    rematchRepairedLengths?: (plans: readonly FanoutRoutePlan[]) => FanoutRoutePlan[] | null;
}
/** Check new copper without reinterpreting retained runs as one replaced edge. */
export declare function changedFanoutCopperIsSelfClear(plan: FanoutRoutePlan, segments: readonly RoutedSegment[], clearance: number, changedSegmentIndices?: ReadonlySet<number>): boolean;
/** Normalize target-side corners, retaining the source prefix and every via. */
export declare function normalizeFanoutPlanTargetPath(params: FanoutPlanCornerNormalizationParams, plan: FanoutRoutePlan, others: readonly FanoutRoutePlan[], bus: PreparedBus, removeReversingCorners?: boolean, chamfer?: number): FanoutRoutePlan | null;
/**
 * Final geometric gate after all tuning. Source prefixes are preserved unless
 * source repair is explicitly requested. Every physical via and exact
 * exit is retained, and original length limits and full copper DRC still apply.
 */
export declare function normalizeFanoutPlanCorners(params: FinalFanoutPlanNormalizationParams): FanoutRoutePlan[] | null;
