import type { LayerReservedBusesParams } from "./route-layer-reserved-buses";
import type { Point2D } from "./types";
/** Assign intact buses before packing a package's independent boundary edges.
 * Constrained buses reserve capacity first; flexible buses account for every
 * earlier assignment instead of all choosing the same otherwise empty layer.
 */
export declare function getMultiEdgeBusTargets(params: LayerReservedBusesParams & {
    /** Caller must implement a legal source-layer final escape for each bus. */
    allowSourceLayerTargets?: boolean;
}): {
    targetLayerByBusId: Map<string, string>;
    exits: Map<number, Point2D>;
} | null;
