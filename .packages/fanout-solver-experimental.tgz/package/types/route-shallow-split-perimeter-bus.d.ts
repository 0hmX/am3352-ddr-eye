import { type SplitBusParams } from "./route-split-perimeter-bus";
import type { SplitPerimeterSources } from "./route-split-perimeter-source-escapes";
import type { RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { FanoutRoutePlan, PreparedBus } from "./types";
export type ShallowSplitBusParams = SplitBusParams & {
    buses: readonly PreparedBus[];
};
export type ShallowSplitBusResult = SplitPerimeterSources & {
    plans: FanoutRoutePlan[];
};
/** Shorten the lower perimeter while preserving its source-layer escape topology. */
export declare function routeShallowSplitPerimeterBusSteps(params: ShallowSplitBusParams): Generator<RouteViaMinimalWindingProgress, ShallowSplitBusResult | null, void>;
