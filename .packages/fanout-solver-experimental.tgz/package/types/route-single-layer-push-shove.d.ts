import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutBorderDistribution, FanoutRoutePlan, PreparedBus } from "./types";
interface PushShoveParams {
    srj: SimpleRouteJson;
    buses: PreparedBus[];
    traceWidth: number;
    clearance: number;
    borderDistribution: FanoutBorderDistribution;
}
export declare function routeSingleLayerWithPushAndShove(params: PushShoveParams): FanoutRoutePlan[] | null;
export {};
