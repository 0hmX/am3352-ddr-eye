/**
 * View horizontal fanout geometry from its opposite edge. A shared memo keeps
 * pad identity intact: clearance checks compare a plan's sourceObstacle with
 * the same obstacle in the transformed SRJ.
 */
export declare function reflectFanoutX<T>(value: T): T;
