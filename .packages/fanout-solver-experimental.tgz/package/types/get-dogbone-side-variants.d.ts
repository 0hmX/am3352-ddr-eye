import type { FanoutDirection, Point2D } from "./types";
/** A bounded fallback for channels trapped by uniform outward dogbones. */
export declare function getDogboneSideVariants(connections: readonly {
    connectionIndex: number;
    sourcePoint: Point2D;
}[], direction: FanoutDirection): number[][];
