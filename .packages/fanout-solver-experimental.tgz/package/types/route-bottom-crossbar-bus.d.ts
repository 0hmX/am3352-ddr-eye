import { type RouteBusParams } from "./route-bus";
import { type RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { PeripheralSourceEscape } from "./route-peripheral-source-escapes";
import type { Bounds, FanoutRoutePlan } from "./types";
/** Use two allowed layers to permute unordered bottom exits into either side of the boundary. */
export declare function routeBottomCrossbarBusSteps(params: RouteBusParams & {
    sourceEscapes: readonly PeripheralSourceEscape[];
    sourceBoundary: Bounds;
    oppositeLayout?: {
        sourcePortOffset: number;
        rowOffset: number;
        compactRows: boolean;
    };
}): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[] | null, void>;
