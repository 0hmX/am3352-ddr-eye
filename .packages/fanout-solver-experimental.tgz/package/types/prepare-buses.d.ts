import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Bounds, FanoutAvailableCornerAndSideInput, FanoutBorderTarget, FanoutDirection, FanoutEdge, FanoutSolverOptions, PreparedBus } from "./types";
export interface AvailableBoundaryRegion {
    direction: FanoutDirection;
    preferredExit: FanoutBorderTarget;
    /** Physical shared-boundary edge selected by the first region token. */
    exitEdge: FanoutEdge;
}
export declare function resolveAvailableBoundaryRegions(value: readonly FanoutAvailableCornerAndSideInput[] | undefined): AvailableBoundaryRegion[] | undefined;
export declare function getRegionAnchor(region: AvailableBoundaryRegion, boundary: Bounds): number;
export declare function prepareFanoutBuses(srj: SimpleRouteJson, options: FanoutSolverOptions): PreparedBus[];
