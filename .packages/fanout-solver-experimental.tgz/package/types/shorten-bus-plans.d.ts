import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Bounds, FanoutRoutePlan, PreparedBus } from "./types";
/** Revisit excessive winding detours after provisional reservations are gone. */
export declare function shortenBusPlans(params: {
    plans: readonly FanoutRoutePlan[];
    bus: PreparedBus;
    srj: SimpleRouteJson;
    sharedBoundary: Bounds;
    layerNames: string[];
    traceWidth: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    clearance: number;
    allowSameNetMerges: boolean;
}): FanoutRoutePlan[];
