import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Point2D, PreparedBus } from "./types";
/**
 * Keep the first trace pitch of later exits available while choosing through
 * vias for an earlier group. These traces are temporary search reservations;
 * the caller retains the original input and emits only its routed connections.
 */
export declare function getBoundaryApproachReservations(params: {
    buses: readonly PreparedBus[];
    excludedBusIds: ReadonlySet<string>;
    exits: ReadonlyMap<number, Point2D>;
    targetLayerByBusId: ReadonlyMap<string, string>;
    traceWidth: number;
    clearance: number;
}): NonNullable<SimpleRouteJson["traces"]>;
