import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutRoutePlan, Point2D, PreparedBus } from "./types";
export interface RepairBoundaryRouteTailsParams {
    inputSrj: SimpleRouteJson;
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    /** Unfinished source prefixes and earlier groups remain hard copper. */
    reservedPlans?: readonly FanoutRoutePlan[];
    layerNames: string[];
    traceWidth: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    clearance: number;
    allowBlindAndBuriedVias?: boolean;
    allowSameNetMerges?: boolean;
    gridStep?: number;
    gridOrigin?: Point2D;
}
/**
 * Replace conflicting final-layer boundary links without moving any real via,
 * source, or endpoint. The original buses remain complete and retain their
 * metadata; only temporary path-search terminals use the retained cutpoints.
 * Returns null when the bounded strip cannot produce fully clear copper.
 */
export declare function repairBoundaryRouteTails(params: RepairBoundaryRouteTailsParams): FanoutRoutePlan[] | null;
