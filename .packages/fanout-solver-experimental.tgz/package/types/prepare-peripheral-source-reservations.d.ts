import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { SourceOriginReservations } from "./route-source-origin-buses";
import type { PreparedBus } from "./types";
export interface PeripheralSourceReservationParams {
    srj: SimpleRouteJson;
    buses: readonly PreparedBus[];
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    allowBlindAndBuriedVias?: boolean;
    /** Inward sites leave the space between the leads and boundary available. */
    side?: "inward" | "outward";
}
/** Lead bodies need an axial escape beyond their ends, not a half-pad-pitch via. */
export declare function preparePeripheralSourceReservations(params: PeripheralSourceReservationParams): SourceOriginReservations | null;
