import type { Obstacle } from "@tscircuit/capacity-autorouter";
import type { Point2D, PreparedBus, RoutedSegment } from "./types";
export interface DogboneViaSiteGeometryRules {
    viaDiameter: number;
    viaHoleDiameter?: number;
    traceWidth: number;
    clearance: number;
    /** Defaults to `clearance` when a hole diameter is supplied. */
    holeToHoleClearance?: number;
    /** Bounds the deterministic backtracking search across all components. */
    maximumSearchStates?: number;
    /**
     * Optional bounded-search preference for boundary-bus dogbones. The sign
     * refers to the axis perpendicular to each bus's local escape direction.
     */
    preferredBoundaryPerpendicularSideByBusId?: ReadonlyMap<string, -1 | 1>;
    /** Prefer the local outward or inward half-pitch row for a boundary bus. */
    preferBoundaryOutwardByBusId?: ReadonlyMap<string, boolean>;
    /** Existing assignments that must be preserved while matching other pads. */
    fixedViaPointsByConnectionIndex?: ReadonlyMap<number, Point2D>;
    /** Prefer these provisional sites, but allow rematching when they conflict. */
    preferredViaPointsByConnectionIndex?: ReadonlyMap<number, Point2D>;
    /** Routed copper that every newly assigned through-via/dogbone must clear. */
    blockingSegments?: readonly {
        connectionIndex: number;
        segment: RoutedSegment;
    }[];
    /** Routed vias that every newly assigned through-via/dogbone must clear. */
    blockingVias?: readonly {
        connectionIndex: number;
        center: Point2D;
        diameter: number;
        spanLayers: readonly string[];
    }[];
    /** Board obstacles outside the source component that dogbones must clear. */
    additionalObstacles?: readonly Obstacle[];
    /** Alternate horizontal plane dogbones across BGA rows. */
    preferPlaneCheckerboardSites?: boolean;
    /** True only when the two connections are allowed to merge copper. */
    canShareCopper?: (firstConnectionIndex: number, secondConnectionIndex: number) => boolean;
}
export interface ComponentDogboneViaSiteCandidate {
    connectionIndex: number;
    point: Point2D;
}
/**
 * Matches every prepared connection to a legal adjacent dogbone via site.
 *
 * Candidate sites are derived from the component pad-center grid: midpoint
 * gaps plus one half-pitch perimeter coordinate on each side. The matcher
 * never infers component or connection metadata from identifiers.
 */
export declare function matchComponentDogboneViaSites(preparedBuses: readonly PreparedBus[], rules: DogboneViaSiteGeometryRules): Map<number, Point2D> | null;
/**
 * Enumerates the same statically legal sites used by the component matcher.
 * This is useful to preserve future dogbone capacity while another bus is
 * being routed; callers must still run the full matcher afterward because
 * these candidates are not mutually assigned.
 */
export declare function getComponentDogboneViaSiteCandidates(preparedBuses: readonly PreparedBus[], rules: DogboneViaSiteGeometryRules): ComponentDogboneViaSiteCandidate[];
/** Try one adjacent site change without releasing any other fixed via. */
export declare function getSingleDogboneViaSiteRepairs(bus: PreparedBus, rules: DogboneViaSiteGeometryRules, fixedViaPointsByConnectionIndex: ReadonlyMap<number, Point2D>): Generator<ReadonlyMap<number, Point2D>, void, unknown>;
