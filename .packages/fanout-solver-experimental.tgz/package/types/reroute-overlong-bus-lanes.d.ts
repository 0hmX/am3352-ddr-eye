import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { FanoutRoutePlan, PreparedBus } from "./types";
export interface RerouteOverlongBusLanesParams {
    inputSrj: SimpleRouteJson;
    /** Every connection's physically clear source or completed fanout copper. */
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    selectedBusIds?: ReadonlySet<string>;
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    maximumPasses?: number;
    maximumConnectionAttempts?: number;
    maximumSearchStates?: number;
}
export interface OverlongBusLaneProgress extends RouteViaMinimalWindingProgress {
    busId: string;
    pass: number;
    connectionAttempt: number;
}
/**
 * Revisit overlong lanes after their neighbors free shorter same-layer paths.
 * Every first/additional via, source prefix, exit and other bus stays reserved.
 * This returns complete copper with improved skew; the caller must still match
 * and validate each entire bus before committing it as a successful fanout.
 */
export declare function rerouteOverlongBusLanesSteps(params: RerouteOverlongBusLanesParams): Generator<OverlongBusLaneProgress, FanoutRoutePlan[] | null, unknown>;
