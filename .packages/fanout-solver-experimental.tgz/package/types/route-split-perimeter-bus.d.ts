import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import { type SplitPerimeterSources } from "./route-split-perimeter-source-escapes";
import type { FanoutRoutePlan, PreparedBus } from "./types";
export type SplitBusParams = SplitPerimeterSources & {
    srj: SimpleRouteJson;
    bus: PreparedBus;
    targetLayer: string;
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    /** Rematch pending sources around a lower band before routing its upper lanes. */
    rematchPendingSources?: {
        connectionIndices: ReadonlySet<number>;
        afterLowerStage: (plans: FanoutRoutePlan[]) => boolean;
    };
};
/** Route a lower separator and an ordered upper bundle around a source field. */
export declare function routeSplitPerimeterBusSteps(params: SplitBusParams): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[] | null, void>;
