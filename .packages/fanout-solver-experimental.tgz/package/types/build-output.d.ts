import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutRoutePlan, SimpleRouteJsonWithFanoutPlanes } from "./types";
export declare function buildOutputSimpleRouteJson(params: {
    inputSrj: SimpleRouteJson;
    plans: FanoutRoutePlan[];
    layerNames: string[];
}): SimpleRouteJsonWithFanoutPlanes;
