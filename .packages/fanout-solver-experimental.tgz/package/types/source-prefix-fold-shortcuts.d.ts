import type { FanoutRoutePlan, Point2D } from "./types";
/**
 * Remove one short returning arm from a private source prefix. The caller must
 * normalize each proposal and check all pads, retained copper, and physical
 * vias. Never change a layer transition or the first via's coordinates.
 */
export declare function sourcePrefixFoldShortcuts(plan: FanoutRoutePlan, clearance: number): Generator<Point2D[]>;
