import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type ReservedViaBusesProgress } from "./route-reserved-via-buses";
import type { FanoutRoutePlan, PreparedBus } from "./types";
export interface RepairBusLengthsWithTransitParams {
    inputSrj: SimpleRouteJson;
    /** Complete, physically clear plans; only length skew may remain invalid. */
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    /** Restrict cleanup without omitting any source or accepted copper. */
    busIds?: readonly string[];
    maximumConnectionAttempts?: number;
    maximumIterationsPerConnection?: number;
}
export interface TransitLengthRepairProgress extends ReservedViaBusesProgress {
    busId: string;
    connectionName: string;
    connectionAttempt: number;
}
/**
 * Shorten overlong lanes through permitted transit layers while preserving
 * their original first via and exact source/exit. Every other complete route
 * stays hard copper. A bus is returned only when its complete skew is repaired;
 * cancellation or an exhausted search never exposes a partially repaired bus.
 */
export declare function repairBusLengthsWithTransitSteps(params: RepairBusLengthsWithTransitParams): Generator<TransitLengthRepairProgress, FanoutRoutePlan[] | null>;
