/**
 * Select one candidate per group under a symmetric pairwise constraint.
 * Arc consistency exposes impossible groups early; deterministic min-conflicts
 * and bounded backtracking handle the remaining nonlocal choices.
 */
export declare function selectCompatibleCandidates<T>(params: {
    candidateSets: readonly (readonly T[])[];
    areCompatible: (first: T, second: T) => boolean;
    maximumSearchStates: number;
}): {
    selection: T[] | null;
    searchStates: number;
    emptyDomainIndices: number[];
    conflictDomainIndices: number[];
};
