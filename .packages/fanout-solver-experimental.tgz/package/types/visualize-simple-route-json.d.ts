import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { GraphicsObject } from "graphics-debug";
export declare function visualizeSimpleRouteJson(srj: SimpleRouteJson): GraphicsObject;
