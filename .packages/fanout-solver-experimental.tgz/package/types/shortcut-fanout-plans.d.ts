import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutRoutePlan, PreparedBus } from "./types";
export interface ShortcutFanoutPlansParams {
    inputSrj: SimpleRouteJson;
    /** Complete copper, including other buses and any reserved source prefixes. */
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    layerNames: readonly string[];
    traceWidth: number;
    clearance: number;
    selectedBusIds?: ReadonlySet<string>;
    selectedConnectionIndices?: ReadonlySet<number>;
    allowBlindAndBuriedVias?: boolean;
    allowSameNetMerges?: boolean;
    /** Shorten pad-clear source copper too, retaining its pad lead and first via. */
    allowSourcePrefixShortcuts?: boolean;
}
/**
 * Bounded same-layer shortcuts for lanes exceeding their original bus minimum
 * plus allowed skew. Every physical via, layer transition and boundary endpoint
 * stays fixed; source prefixes stay fixed unless explicitly enabled. No bus
 * minimum is lowered; remaining skew is
 * handled by the caller's length matcher. Null means complete copper validation
 * failed, so the caller must retain its original plans.
 */
export declare function shortcutFanoutPlans(params: ShortcutFanoutPlansParams): FanoutRoutePlan[] | null;
