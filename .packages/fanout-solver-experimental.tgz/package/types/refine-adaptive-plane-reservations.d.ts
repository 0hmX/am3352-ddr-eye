import type { PreparedBus } from "./types";
/**
 * A failed arc-consistency chain ends with the domain that removed the last
 * supported candidate. When that plane pad has an adjacent peer farther into
 * the component, reserving the peer keeps the outer pad available for a
 * displaced route while protecting the same local dogbone corridor.
 */
export declare function refineAdaptivePlaneReservationCore(params: {
    candidateBusIds: readonly string[];
    activeBusIds: ReadonlySet<string>;
    planeBuses: readonly PreparedBus[];
}): string[];
