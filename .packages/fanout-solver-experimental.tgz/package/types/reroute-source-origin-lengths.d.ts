import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type ReservedViaBusesProgress } from "./route-reserved-via-buses";
import type { FanoutRoutePlan, PreparedBus } from "./types";
export interface RerouteSourceOriginLengthsParams {
    inputSrj: SimpleRouteJson;
    /** Include every original connection, with unfinished routes as source prefixes. */
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    bus: PreparedBus;
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    /** Optional original bus-permitted layers for provisional length cleanup. */
    transitLayers?: readonly string[];
}
/**
 * Reconsider first vias for an intact mismatched pair, or at most two overlong
 * lanes of a wider bus. Other sources and completed copper remain hard. The
 * returned full candidate is provisional: its complete bus must still pass
 * length matching before its new source reservations can be committed.
 */
export declare function rerouteSourceOriginLengthsSteps(params: RerouteSourceOriginLengthsParams): Generator<ReservedViaBusesProgress, FanoutRoutePlan[] | null>;
