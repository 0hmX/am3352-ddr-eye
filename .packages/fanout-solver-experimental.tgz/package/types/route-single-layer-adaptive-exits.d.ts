import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { GraphicsObject } from "graphics-debug";
import { type AvailableBoundaryRegion } from "./prepare-buses";
import type { FanoutRoutePlan, PreparedBus } from "./types";
interface FlowRoutingParams {
    srj: SimpleRouteJson;
    buses: PreparedBus[];
    traceWidth: number;
    clearance: number;
    availableBoundaryRegions?: AvailableBoundaryRegion[];
    /** Provisional clear source prefixes; callers must preserve unmatched inputs. */
    onPartialRoutes?: (plans: FanoutRoutePlan[]) => void;
    onProgress?: (visualization: GraphicsObject, stats: Record<string, unknown>) => void;
}
export declare function routeSingleLayerWithAdaptiveExitsSteps(params: FlowRoutingParams): Generator<void, FanoutRoutePlan[] | null, unknown>;
export declare function routeSingleLayerWithAdaptiveExits(params: FlowRoutingParams): FanoutRoutePlan[] | null;
export {};
