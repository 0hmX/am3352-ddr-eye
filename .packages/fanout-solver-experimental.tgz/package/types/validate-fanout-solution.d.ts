import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Bounds, FanoutRoutePlan, FanoutValidationReport, PreparedBus } from "./types";
export declare function validateFanoutSolution(params: {
    inputSrj: SimpleRouteJson;
    outputSrj: SimpleRouteJson;
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    sharedBoundary: Bounds;
    clearance: number;
    allowBlindAndBuriedVias?: boolean;
}): FanoutValidationReport;
