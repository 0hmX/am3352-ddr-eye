import type { FanoutBorderTarget, FanoutDirection, FanoutEdge } from "./types";
export declare function getExitEdgeForDirection(direction: FanoutDirection): FanoutEdge;
export declare function getDirectionForExitEdge(exitEdge: FanoutEdge): FanoutDirection;
export declare function borderTargetIncludesEdge(preferredExit: FanoutBorderTarget, exitEdge: FanoutEdge): boolean;
/**
 * Returns the lower/left or upper/right band selected along an explicit edge.
 * Edge-center targets do not select a corner band.
 */
export declare function getCornerBandSide(exitEdge: FanoutEdge | undefined, preferredExit: FanoutBorderTarget | undefined): "minimum" | "maximum" | undefined;
