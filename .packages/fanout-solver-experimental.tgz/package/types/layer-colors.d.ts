export declare function getCopperLayerColor(layerIndex: number): string;
