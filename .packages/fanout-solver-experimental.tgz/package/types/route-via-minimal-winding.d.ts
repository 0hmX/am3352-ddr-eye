import type { Obstacle, SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { GraphicsObject } from "graphics-debug";
import type { FanoutRoutePlan, Point2D, PreparedBus, PreparedConnection, RoutedSegment, RoutedVia } from "./types";
export interface ViaMinimalWindingTerminal {
    connection: PreparedConnection;
    viaPoint: Point2D;
    exitPoint: Point2D;
}
export interface ViaMinimalWindingReservedVia {
    connectionName: string;
    via: Pick<RoutedVia, "center" | "diameter" | "spanLayers">;
    /** Keep the future pad-to-via dogbone available during source-layer escape. */
    sourceEscapeSegment?: RoutedSegment;
}
export interface RouteViaMinimalWindingParams {
    srj: SimpleRouteJson;
    bus: PreparedBus;
    targetLayer: string;
    terminals: ViaMinimalWindingTerminal[];
    acceptedPlans: FanoutRoutePlan[];
    layerNames: string[];
    traceWidth: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    clearance: number;
    allowBlindAndBuriedVias?: boolean;
    allowSameNetMerges?: boolean;
    maximumRouteOrderAttempts?: number;
    /** Per-terminal directed-state budget; the default search budget is unchanged. */
    maximumSearchStates?: number;
    reservedVias?: readonly ViaMinimalWindingReservedVia[];
    /** Cost hints for provisional sites that the caller must rematch before commit. */
    softReservedVias?: readonly ViaMinimalWindingReservedVia[];
    /** Use a finer uniform grid for narrow channels between reserved vias. */
    gridStepDivisor?: 1 | 2;
    /** Exact grid spacing for staged routing through narrow via channels. */
    gridStep?: number;
    /** Optional lattice origin for staged paths whose retained cuts lie on a grid. */
    gridOrigin?: Point2D;
    /** Search priority weight; values above one return the first valid goal. */
    heuristicWeight?: number;
    /** Deterministic terminal order for a caller that has ordered escape ports. */
    routeOrder?: readonly number[];
    /** Side preference for a caller-supplied terminal order. */
    laneBias?: -1 | 0 | 1;
    /** Actual copper before the first via when source escape has multiple bends. */
    sourceEscapePaths?: ReadonlyMap<number, readonly Point2D[]>;
    /** Bias bounded fixed-site searches toward the remote target band. */
    preferTargetDirectedLaneBias?: boolean;
    /** Keep the shared boundary untouched until the exact terminal point. */
    forbidEarlyExitBoundaryContact?: boolean;
    /** Internal path-only mode used before a boundary-side via is appended. */
    allowSourceLayerRouting?: boolean;
    /** Promote a blocked terminal while staying within maximumRouteOrderAttempts. */
    adaptiveRouteOrder?: boolean;
    /** Align a fine grid with pad/interstice centers instead of the boundary. */
    alignGridToPads?: boolean;
    /** Defer the outermost reversed target while routing the inner terminals. */
    includeReverseTargetRotation?: boolean;
    /** Keep earlier lanes clear of every remaining terminal exit. */
    reserveTerminalExitPoints?: boolean;
}
export interface RouteViaMinimalWindingProgress {
    phase: "route-connection";
    routeOrderAttempt: number;
    connectionIndex: number;
    connectionCount: number;
    connectionName: string;
    searchBatch: number;
    expandedStateCount: number;
    connectionComplete: boolean;
    visualization?: GraphicsObject;
}
/**
 * X-sorted broad phase for exact segment-to-obstacle clearance checks.
 * Rotation-aware bounds make the query conservative; callers still use the
 * shape-aware distance function to decide whether copper is actually blocked.
 */
export declare class ObstacleSpatialIndex {
    private readonly obstaclesByCenterX;
    private readonly maximumXRadius;
    constructor(obstacles: readonly Obstacle[]);
    querySegment(segment: RoutedSegment, margin: number): Obstacle[];
}
export declare function iterateUniqueRouteOrders<T>(params: {
    initialOrderFactories: ReadonlyArray<() => readonly T[]>;
    rotationBase: readonly T[];
    getItemKey: (item: T) => string;
    maximumOrderCount?: number;
}): Generator<readonly T[]>;
export declare function buildViaMinimalWindingPlan(params: {
    bus: PreparedBus;
    terminal: ViaMinimalWindingTerminal;
    targetLayer: string;
    targetLayerPoints: Point2D[];
    sourceEscapePoints?: readonly Point2D[];
    layerNames: string[];
    traceWidth: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    allowBlindAndBuriedVias: boolean;
}): FanoutRoutePlan;
export declare function routeViaMinimalWindingAlternativesSteps(params: RouteViaMinimalWindingParams, maximumAlternatives?: number, includeVisualization?: boolean): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[][], void>;
export declare function routeViaMinimalWindingAlternatives(params: RouteViaMinimalWindingParams, maximumAlternatives?: number): FanoutRoutePlan[][];
export declare function routeViaMinimalWinding(params: RouteViaMinimalWindingParams): FanoutRoutePlan[] | null;
