import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Bounds, FanoutRoutePlan, Point2D, PreparedBus } from "./types";
export interface PlaneReservedSourceEscapeParams {
    srj: SimpleRouteJson;
    buses: readonly PreparedBus[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    maximumSearchStates?: number;
}
export interface PlaneReservedSourceEscapes {
    /** Before-via prefixes only; original buses still require complete routes. */
    prefixPlans: FanoutRoutePlan[];
    sourceBoundary: Bounds;
    fixedPlaneSites: Map<number, Point2D>;
    remainingViaPointsByConnectionIndex: Map<number, Point2D>;
}
/**
 * Reserve every local plane escape, then find source-layer signal prefixes
 * without consuming the via capacity needed by any unmatched connection.
 * Nothing is committed: the caller must extend these prefixes through legal
 * vias and finish each original atomic bus before accepting a solution.
 */
export declare function routePlaneReservedSourceEscapesSteps(params: PlaneReservedSourceEscapeParams): Generator<void, PlaneReservedSourceEscapes | null, unknown>;
