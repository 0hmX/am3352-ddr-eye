export interface LayerRoutingAttempt {
    ripCost: number;
    shuffleSeed: number;
    transitLayers: string[];
    routeFromSourcePads?: boolean;
    sourceOriginPhysicalGridPhase?: boolean;
    sourceLayerTravelCost?: number;
    maximumSourceIterations?: number;
    reserveFutureApproaches?: boolean;
}
/** Bounded retry order; successful attempts never schedule extra work. */
export declare class LayerRoutingAttempts {
    private readonly options;
    private readonly pending;
    private readonly attempted;
    private readonly preferredOrder?;
    private readonly originalOrder?;
    constructor(options: {
        wideSingleLayer: boolean;
        firstRipCost: number;
        transitLayers: string[];
        allTransitLayers: string[];
        preferSourceTransit?: boolean;
        preferSourceOrigin?: boolean;
        sourceOriginRipCost?: number;
        sourceTransitRipCost?: number;
        retrySourceOriginPhysicalGridPhase?: boolean;
        retrySourceOriginFreshReservations?: boolean;
        preferAlternateOrder?: boolean;
    });
    next(): LayerRoutingAttempt | undefined;
    failed(attempt: LayerRoutingAttempt, reason: "routing" | "lengths"): void;
}
