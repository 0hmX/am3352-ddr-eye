import { type RouteBusAlternativesProgress, type RouteBusParams } from "./route-bus";
import type { FanoutRoutePlan, PreparedBus } from "./types";
interface Params extends Omit<RouteBusParams, "bus"> {
    buses: readonly PreparedBus[];
}
/** Route fixed-via small buses together so an early lane cannot trap a later bus. */
export declare function routeReservedNarrowBusesSteps(params: Params): Generator<RouteBusAlternativesProgress, FanoutRoutePlan[] | null, void>;
export {};
