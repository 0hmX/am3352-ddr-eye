import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Bounds, FanoutRoutePlan, Point2D, PreparedBus } from "./types";
export interface LayerReservedSourceEscapeParams {
    srj: SimpleRouteJson;
    buses: readonly PreparedBus[];
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    maximumSearchStates?: number;
    /** An existing complete local matching whose sites must start unchanged. */
    initialViaPointsByConnectionIndex?: ReadonlyMap<number, Point2D>;
}
export interface LayerReservedSourceEscapes {
    sourceBoundary: Bounds;
    /** Complete reservations, including every local and remote through via. */
    fixedViaPointsByConnectionIndex: Map<number, Point2D>;
    sourceEscapePaths: Map<number, readonly Point2D[]>;
    /** Every connection's source copper; these are not completed boundary buses. */
    sourcePlans: FanoutRoutePlan[];
    /** The preserved source-layer prefixes before their outward via stubs. */
    prefixPlans: FanoutRoutePlan[];
    remotePlans: FanoutRoutePlan[];
    layerGroups: Array<{
        layer: string;
        connectionCount: number;
        escapedCount: number;
    }>;
}
/**
 * Prepare source escapes one constrained target layer at a time. Wider buses
 * go first, with every other source's real copper and through via reserved.
 * This returns complete source reservations only; callers must still route
 * and validate every original atomic bus before committing a solution.
 */
export declare function routeLayerReservedSourceEscapesSteps(params: LayerReservedSourceEscapeParams): Generator<void, LayerReservedSourceEscapes | null, unknown>;
