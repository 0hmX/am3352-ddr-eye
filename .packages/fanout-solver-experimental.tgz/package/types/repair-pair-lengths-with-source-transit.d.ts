import type { RerouteSourceOriginLengthsParams } from "./reroute-source-origin-lengths";
import { type ReservedViaBusesProgress } from "./route-reserved-via-buses";
import type { FanoutRoutePlan } from "./types";
/** Reconsider one failed pair's source vias and permitted transit layer atomically. */
export declare function repairPairLengthsWithSourceTransitSteps(params: RerouteSourceOriginLengthsParams): Generator<ReservedViaBusesProgress, FanoutRoutePlan[] | null>;
