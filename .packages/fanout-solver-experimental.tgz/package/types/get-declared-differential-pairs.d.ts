import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
export interface DeclaredDifferentialPair {
    connectionNames: [string, string];
    connectionIndices: [number, number];
    lengthTolerance: number;
}
/** Resolve only original connection identities; electrical aliases are not pair names. */
export declare function getDeclaredDifferentialPairs(srj: SimpleRouteJson): DeclaredDifferentialPair[];
