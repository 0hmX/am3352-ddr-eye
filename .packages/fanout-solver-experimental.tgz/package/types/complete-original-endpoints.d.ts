import type { SimpleRouteJson, SimplifiedPcbTrace } from "@tscircuit/capacity-autorouter";
import type { FanoutDownstreamRouter, FanoutEndpointCompletionReport, FanoutRoutePlan } from "./types";
export interface CompleteOriginalEndpointsResult {
    simpleRouteJson: SimpleRouteJson;
    traces: SimplifiedPcbTrace[];
    report: FanoutEndpointCompletionReport;
}
/**
 * Connects short opposite-layer terminal pairs with constrained interstitial
 * vias, then delegates remaining long routes to an optional host-provided
 * router. Only metric-improving, independently DRC-clean physical copper is
 * retained.
 */
export declare function completeOriginalEndpoints(params: {
    inputSrj: SimpleRouteJson;
    fanoutSrj: SimpleRouteJson;
    plans: FanoutRoutePlan[];
    traceWidth: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    clearance: number;
    allowBlindAndBuriedVias?: boolean;
    effort?: number;
    routeDownstreamConnections?: FanoutDownstreamRouter;
}): CompleteOriginalEndpointsResult;
