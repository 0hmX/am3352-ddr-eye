import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutSimplifiedPcbTrace, SimpleRouteJsonWithFanoutPlanes } from "./types";
export declare function addViaLayerMetadataToTrace(params: {
    trace: FanoutSimplifiedPcbTrace;
    layerNames: string[];
    allowBlindAndBuriedVias: boolean;
}): FanoutSimplifiedPcbTrace;
export declare function addViaLayerMetadataToSrj(params: {
    srj: SimpleRouteJsonWithFanoutPlanes | SimpleRouteJson;
    layerNames: string[];
    allowBlindAndBuriedVias: boolean;
}): SimpleRouteJsonWithFanoutPlanes;
