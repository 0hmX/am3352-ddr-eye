import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type ReservedViaBusesProgress } from "./route-reserved-via-buses";
import type { FanoutRoutePlan, PreparedBus } from "./types";
export interface RetainedBoundaryTailRepairParams {
    inputSrj: SimpleRouteJson;
    /** Complete physical routing; selected buses may still violate length skew. */
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    busIds?: readonly string[];
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    maximumIterationsPerAttempt?: number;
}
export interface RetainedBoundaryTailRepairProgress extends ReservedViaBusesProgress {
    busId: string;
    phase: "lane" | "bus" | "layer" | "overlong-pair";
}
declare function getRetainedTail(plan: FanoutRoutePlan, bus: PreparedBus, width: number): FanoutRoutePlan | null;
export { getRetainedTail as getRetainedBoundaryTail };
/**
 * Two long lanes can fence each other out of a shorter transit corridor.
 * Reconsider only those lanes together, keeping all other copper and every
 * original first via fixed. Return only after the intact bus matches.
 */
export declare function rerouteTwoOverlongLanesSteps(params: RetainedBoundaryTailRepairParams): Generator<RetainedBoundaryTailRepairProgress, FanoutRoutePlan[] | null>;
/** Preserve every successful existing repair before trying two blocked lanes. */
export declare function rerouteBusWithRetainedBoundaryTailsSteps(params: RetainedBoundaryTailRepairParams): Generator<RetainedBoundaryTailRepairProgress, FanoutRoutePlan[] | null>;
