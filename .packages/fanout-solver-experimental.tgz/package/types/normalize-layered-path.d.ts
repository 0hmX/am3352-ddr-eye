import type { Point2D } from "./types";
export interface LayeredPathPoint extends Point2D {
    z: number;
}
/** Keep exact terminals/vias while replacing grid corners and endpoint links. */
export declare function normalizeLayeredPath(params: {
    points: readonly LayeredPathPoint[];
    chamfer: number;
    /** Repair selected final paths without admitting new intermediate candidates. */
    repairReversingDiagonalCorners?: boolean;
    segmentIsClear: (start: LayeredPathPoint, end: LayeredPathPoint) => boolean;
}): LayeredPathPoint[] | null;
