import type { Point2D, PreparedBus } from "./types";
/**
 * Select a constrained pair group whose fixed source escapes repeatedly send
 * paired lanes in opposite directions. A remote via beyond the far component
 * edge makes its lane return across the package, while its local mate already
 * advances toward the exit. Choose first vias jointly when multiple pairs
 * have this geometry; a lone affected pair keeps the ordinary routing path.
 */
export declare function hasOpposedPairSourceEscapes(params: {
    buses: readonly PreparedBus[];
    fixedViaPointsByConnectionIndex: ReadonlyMap<number, Point2D>;
    clearance: number;
}): boolean;
/** Preserve layer-group boundaries when inspecting the initial source map. */
export declare function getOpposedPairSourceGroups(params: {
    groups: readonly (readonly PreparedBus[])[];
    fixedViaPointsByConnectionIndex: ReadonlyMap<number, Point2D>;
    clearance: number;
}): readonly (readonly PreparedBus[])[];
