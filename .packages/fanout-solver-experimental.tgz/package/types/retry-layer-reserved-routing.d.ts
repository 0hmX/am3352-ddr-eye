import type { LayerReservedRoutingYield } from "./route-layer-reserved-buses";
import type { FanoutRoutePlan } from "./types";
export interface LayerReservedAttemptState {
    reserveFutureApproaches: boolean;
    failedNarrowGroup: boolean;
    failedWideMatching: boolean;
}
/**
 * Future approach traces guide first-via placement, but can select a topology
 * that a wide bus cannot length-match or later pairs cannot route. Retry with
 * fresh source reservations once after either failure. Successful routes and
 * failures during source placement or wide-bus routing keep their first path.
 */
export declare function retryLayerReservedRoutingSteps(sourceOriginRouting: boolean, attempt: (state: LayerReservedAttemptState) => Generator<LayerReservedRoutingYield, FanoutRoutePlan[] | null, unknown>): Generator<LayerReservedRoutingYield, FanoutRoutePlan[] | null, unknown>;
