interface TransitSearchRouter {
    failed: boolean;
    planeSize: number;
    layers: number;
    activeConnId: number;
    activeConnSeg: {
        startCellId: number;
        endCellId: number;
        startZ: number;
        endZ: number;
    } | null;
    cellCenterX: Float64Array;
    cellCenterY: Float64Array;
    visitedStamp: Uint32Array;
    bestGStamp: Uint32Array;
    bestGValue: Float64Array;
    nodePool: {
        z: Int32Array;
        cellId: Int32Array;
        push(z: number, cell: number, g: number, parent: number, ripHead: number, ripCount: number): number;
    };
    heap: {
        pop(): number;
    };
    getSearchStateIdx(flat: number, ripCount: number): number;
}
/** Add path history to search keys while all copper keeps its physical cell/layer. */
export declare function attachSourceOriginTransitSearch(router: TransitSearchRouter, requiresTransit: readonly boolean[], topZ: number, minimumViaDistance: number): {
    beforeFirstVia: () => boolean;
    /** Called before the native move's state-key lookup, even if this move is rejected. */
    prepareMove(z: number, cell: number, isVia: boolean): boolean;
};
export {};
