import type { RouteBusParams } from "./route-bus";
/** Midpoints of unoccupied edge intervals, clipped to the bus's declared band. */
export declare function getFreeBoundaryTracks(params: Pick<RouteBusParams, "bus" | "targetLayer" | "acceptedPlans" | "reservedVias" | "traceWidth" | "clearance">): number[];
