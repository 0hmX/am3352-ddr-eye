import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { type ReservedViaBusesSubsolverRequest } from "./route-reserved-via-buses";
import type { FanoutRoutePlan, Point2D, PreparedBus } from "./types";
export interface LayerReservedBusesParams {
    srj: SimpleRouteJson;
    buses: readonly PreparedBus[];
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    /** Choose first vias jointly for the widest constrained source group. */
    sourceOriginRouting?: boolean;
}
export interface LayerReservedRoutingProgress {
    type?: never;
    phase: "sources" | "route-layer" | "match-layer" | "repair-lengths";
    layer?: string;
    routedConnectionCount: number;
    iterations?: number;
}
export type LayerReservedRoutingYield = LayerReservedRoutingProgress | ReservedViaBusesSubsolverRequest;
export declare function getLayerReservedBusTargets(params: LayerReservedBusesParams): {
    targetLayerByBusId: Map<string, string>;
    exits: Map<number, Point2D>;
} | null;
/** Finish each target layer around a complete, shared set of source reservations. */
export declare function routeLayerReservedBusesSteps(params: LayerReservedBusesParams): Generator<LayerReservedRoutingYield, FanoutRoutePlan[] | null, unknown>;
