import type { Point2D } from "./types";
export interface ViaChannelGridSite {
    connectionIndex: number;
    center: Point2D;
    diameter: number;
}
export interface ViaChannelGridPhaseParams {
    /** All physical vias spanning the layer, including future reservations. */
    vias: readonly ViaChannelGridSite[];
    /** Prefer channels incident to the connections currently being routed. */
    activeConnectionIndices: ReadonlySet<number>;
    traceWidth: number;
    clearance: number;
    gridStep: number;
}
/**
 * Choose one uniform-grid origin for the complete shared layer. Adjacent vias
 * define intervals in which two grid lanes can meet the exact trace pitch.
 * A circular interval sweep favors active channels, then all other channels.
 * Prefer the midpoint of a positive-width plateau to a fragile endpoint gain.
 * This is a search hint; callers must still validate all routed copper.
 */
export declare function getViaChannelGridPhase(params: ViaChannelGridPhaseParams): Point2D;
