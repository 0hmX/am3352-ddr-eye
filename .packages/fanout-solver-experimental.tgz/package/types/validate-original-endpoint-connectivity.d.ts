import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
export interface OriginalEndpointConnectivityIssue {
    code: "original-endpoints-disconnected";
    connectionName: string;
    disconnectedEndpointIndices: number[];
    message: string;
}
export interface OriginalEndpointConnectivityReport {
    valid: boolean;
    checkedConnectionCount: number;
    connectedConnectionCount: number;
    checkedEndpointCount: number;
    connectedEndpointCount: number;
    issues: OriginalEndpointConnectivityIssue[];
}
/**
 * Independently proves that emitted copper connects every original SRJ
 * endpoint. Merely reaching a boundary or retaining an endpoint in the output
 * connection metadata does not count as connectivity.
 */
export declare function validateOriginalEndpointConnectivity(params: {
    inputSrj: SimpleRouteJson;
    routedSrj: SimpleRouteJson;
}): OriginalEndpointConnectivityReport;
