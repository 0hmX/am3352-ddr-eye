import type { Point2D, PreparedBus } from "./types";
/** Prefer new source sites when an opposite wide bus exits across the pad field. */
export declare function hasOppositeWideExitOverSourceField(buses: readonly PreparedBus[], exits: ReadonlyMap<number, Point2D>): boolean;
