import type { Obstacle } from "@tscircuit/capacity-autorouter";
import type { Point2D, RoutedSegment } from "./types";
export declare function distance(a: Point2D, b: Point2D): number;
export declare function distancePointToSegment(point: Point2D, start: Point2D, end: Point2D): number;
export declare function distanceSegmentToSegment(firstStart: Point2D, firstEnd: Point2D, secondStart: Point2D, secondEnd: Point2D): number;
export declare function pointIsInsideObstacle(point: Point2D, obstacle: Obstacle, tolerance?: number): boolean;
export declare function circleFitsInsideObstacle(params: {
    center: Point2D;
    diameter: number;
    obstacle: Obstacle;
    tolerance?: number;
}): boolean;
export declare function distancePointToObstacle(point: Point2D, obstacle: Obstacle): number;
export declare function distanceSegmentToObstacle(segment: RoutedSegment, obstacle: Obstacle): number;
export declare function segmentsAreClear(first: RoutedSegment, second: RoutedSegment, clearance: number): boolean;
