import { type DogboneViaSiteGeometryRules } from "./match-component-dogbone-via-sites";
import type { Point2D, PreparedBus } from "./types";
/** Reserve ordered source vias, then assign every remaining source via together. */
export declare function matchAngularlyOrderedLocalVias(params: {
    buses: readonly PreparedBus[];
    busId: string;
    rules: DogboneViaSiteGeometryRules;
    maximumOrderingStates?: number;
    maximumCompleteAssignments?: number;
}): Map<number, Point2D> | null;
