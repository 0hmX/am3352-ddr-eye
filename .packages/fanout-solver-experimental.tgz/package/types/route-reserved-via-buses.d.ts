import { type SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { SubsolverRequest } from "./subsolver-request";
import { type ViaMinimalWindingTerminal } from "./route-via-minimal-winding";
import type { FanoutRoutePlan, Point2D, PreparedBus } from "./types";
export interface RouteReservedViaBusesParams {
    srj: SimpleRouteJson;
    allBuses: readonly PreparedBus[];
    buses: readonly PreparedBus[];
    targetLayer: string;
    /** Opt-in joint search with one final layer per intact bus. Every selected bus must be mapped. */
    targetLayerByBusId?: ReadonlyMap<string, string>;
    /** Fixed first-via landing layers, specified independently of the final layers. Every selected bus must be mapped. */
    startLayerByBusId?: ReadonlyMap<string, string>;
    /** Optional bus-permitted transit layers. TOP return requires allowSourceOriginTopFinal. */
    transitLayers?: readonly string[];
    terminals: readonly ViaMinimalWindingTerminal[];
    fixedViaPointsByConnectionIndex: ReadonlyMap<number, Point2D>;
    sourceEscapePaths?: ReadonlyMap<number, readonly Point2D[]>;
    acceptedPlans: readonly FanoutRoutePlan[];
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    maximumIterations?: number;
    /** Opt-in 45-degree adjacency; exact copper checks still guard every edge. */
    includeDiagonalNeighbors?: boolean;
    /** Native Euclidean heuristic multiplier; defaults to the established 1.5. */
    heuristicWeight?: number;
    shuffleSeed?: number;
    /** Align a uniform grid and its center keepouts with narrow via channels. */
    tightViaChannels?: boolean;
    ripCost?: number;
    maximumRipEvents?: number;
    /** Bound local reroutes after a validated candidate is one connection short. */
    maximumLocalRepairAttempts?: number;
    /** Opt-in completion of one missing source-origin lane around retained copper. */
    maximumSourceOriginRepairAttempts?: number;
    /** Additional conservative spacing beyond the physical edge clearance. */
    traceMarginExtra?: number;
    /** Jointly choose each selected TOP source's first through via. */
    routeFromSourcePads?: boolean;
    /** Permit originally allowed TOP final layers after real internal travel through distinct through-vias. */
    allowSourceOriginTopFinal?: boolean;
    /** Search-only cost for TOP travel before that first via; defaults to one. */
    sourceLayerTravelCost?: number;
    /** Score source-origin grid channels using only vias that remain reserved. */
    sourceOriginPhysicalGridPhase?: boolean;
    /** Reserve an exact perpendicular exit tail and use checked 45-degree entry links. */
    terminalApproachLength?: number;
}
export interface ReservedViaBusesProgress {
    iterations: number;
    routedConnectionCount: number;
    connectionCount: number;
}
export type ReservedViaBusesSubsolverRequest = ReservedViaBusesProgress & SubsolverRequest;
export type ReservedViaBusesYield = ReservedViaBusesProgress | ReservedViaBusesSubsolverRequest;
/** Negotiated fixed-via routing; only fully validated, complete buses are returned. */
export declare function routeReservedViaBusesSteps(params: RouteReservedViaBusesParams): Generator<ReservedViaBusesYield, FanoutRoutePlan[] | null, unknown>;
/** Complete a provisional source-origin group, keeping its routed lanes hard.
 * The sole missing source may choose its first via and permitted transit layers.
 * Returns the entire group after original copper validation, never a partial bus.
 */
export declare function completeSourceOriginBusSteps(params: RouteReservedViaBusesParams, partial: readonly FanoutRoutePlan[]): Generator<ReservedViaBusesProgress, FanoutRoutePlan[] | null, unknown>;
