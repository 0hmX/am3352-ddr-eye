export interface RuntimeProcess {
    env: Record<string, string | undefined>;
}
interface RuntimeGlobal {
    process?: RuntimeProcess;
}
export declare const getRuntimeProcess: (runtime: RuntimeGlobal) => RuntimeProcess;
export {};
