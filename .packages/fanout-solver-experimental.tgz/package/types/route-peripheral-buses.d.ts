import type { LayerReservedBusesParams, LayerReservedRoutingYield } from "./route-layer-reserved-buses";
import type { FanoutRoutePlan } from "./types";
/** Route a four-sided lead package as one transaction across its permitted signal layers. */
export declare function routePeripheralBusesSteps(params: LayerReservedBusesParams & {
    allowBlindAndBuriedVias?: boolean;
}): Generator<LayerReservedRoutingYield, FanoutRoutePlan[] | null, unknown>;
