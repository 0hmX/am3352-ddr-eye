import type { PreparedBus } from "./types";
export type DenseBoundaryRoutingMode = "mixed_with_planes" | "large_boundary_only";
export declare function shouldUseJointBoundaryViaReservation(boundaryBusConnectionCounts: readonly number[]): boolean;
export declare function getDenseBoundaryRoutingMode({ boundaryBusConnectionCounts, planeBusCount, }: {
    boundaryBusConnectionCounts: readonly number[];
    planeBusCount: number;
}): DenseBoundaryRoutingMode | null;
export declare function orderDenseBoundaryBusesForRouting({ busesInRoutingOrder, busLayerAssignments, routingMode, }: {
    busesInRoutingOrder: readonly PreparedBus[];
    busLayerAssignments: Readonly<Record<string, string>>;
    routingMode: DenseBoundaryRoutingMode;
}): PreparedBus[];
