import type { Point2D } from "./types";
/** Same-net DRC cannot detect copper that bypasses an earlier part of this route. */
export declare function sourceOriginRouteIsSelfClear(params: {
    points: readonly (Point2D & {
        z: number;
    })[];
    topZ: number;
    traceWidth: number;
    viaDiameter: number;
    clearance: number;
}): boolean;
