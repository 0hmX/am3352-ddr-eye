import type { FanoutEdge, PreparedBus } from "./types";
export interface PackedBoundaryBusInterval {
    busId: string;
    layer: string;
    edge: FanoutEdge;
    minimum: number;
    maximum: number;
    connectionIndices: number[];
    desiredTracks: number[];
    tracks: number[];
    desiredStart: number;
    desiredEnd: number;
    start: number;
    end: number;
    shift: number;
}
/** Translate whole bus intervals while preserving each lane's identity,
 * order, spacing, assigned layer, and original shared-boundary edge. Minimize
 * squared movement of individual connection targets with weighted isotonic PAV.
 */
export declare function packBoundaryBusIntervals(params: {
    buses: readonly PreparedBus[];
    targetLayerByBusId: ReadonlyMap<string, string>;
    layerNames: readonly string[];
    traceWidth: number;
    viaDiameter: number;
    clearance: number;
}): {
    tracksByConnectionIndex: Map<number, number>;
    intervals: PackedBoundaryBusInterval[];
};
