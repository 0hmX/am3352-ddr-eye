export interface FanoutOutputIds {
    boundaryExitPointId: string;
    planeExitPointId: string;
    traceId: string;
    viaObstacleId: string;
    planeEndpointPointId: string;
    planeEndpointTraceId: string;
    planeEndpointViaObstacleId: string;
}
export declare function createFanoutOutputIds(input: {
    connectionName: string;
    sourcePointIndex: number;
}): FanoutOutputIds;
export declare function createFanoutCompletionTraceId(input: {
    connectionName: string;
    sourcePointIndex: number;
    candidateIndex: number;
}): string;
