import type { RoutedSegment, RoutedVia } from "./types";
/** Immutable, layer-aware broad phase. Callers retain exact clearance checks. */
export declare class RouteSegmentSpatialIndex {
    private layers;
    constructor(segments: readonly RoutedSegment[]);
    querySegment(segment: RoutedSegment, clearance: number): RoutedSegment[];
    queryVia(via: RoutedVia, clearance: number): RoutedSegment[];
    private query;
    private build;
}
