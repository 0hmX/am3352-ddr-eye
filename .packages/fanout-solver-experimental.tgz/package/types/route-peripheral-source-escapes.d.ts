import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Bounds, Point2D, PreparedBus, RoutedSegment, RoutedVia } from "./types";
export interface PeripheralSourceEscape {
    connectionIndex: number;
    connectionName: string;
    segments: RoutedSegment[];
    via: RoutedVia;
}
export interface PeripheralSourceEscapes {
    sourceEscapes: PeripheralSourceEscape[];
    viaPointsByConnectionIndex: Map<number, Point2D>;
    remoteConnectionIndices: Set<number>;
    localBus: PreparedBus;
    sourceBoundary: Bounds;
}
export interface PeripheralSourceEscapeParams {
    srj: SimpleRouteJson;
    buses: readonly PreparedBus[];
    bus: PreparedBus;
    targetLayer: string;
    layerNames: string[];
    traceWidth: number;
    clearance: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    allowBlindAndBuriedVias?: boolean;
    initialViaPoints?: ReadonlyMap<number, Point2D>;
    targetPointsByConnectionIndex?: ReadonlyMap<number, Point2D>;
    targetLayerByBusId?: ReadonlyMap<string, string>;
}
/**
 * Escape an ordered subset on its source layer before assigning the remaining
 * vias. Returned prefixes stop at the first via; the caller must complete and
 * validate the whole atomic bus before accepting any of them.
 */
export declare function routePeripheralSourceEscapesSteps(params: PeripheralSourceEscapeParams): Generator<void, PeripheralSourceEscapes | null, unknown>;
