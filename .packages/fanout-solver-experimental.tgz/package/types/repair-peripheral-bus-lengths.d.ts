import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { RouteBusParams } from "./route-bus";
import { type RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { Bounds, FanoutRoutePlan, PreparedBus } from "./types";
interface Params extends Omit<RouteBusParams, "bus" | "targetLayer" | "acceptedPlans"> {
    inputSrj: SimpleRouteJson;
    sharedBoundary: Bounds;
    preparedBuses: readonly PreparedBus[];
    plans: readonly FanoutRoutePlan[];
}
/** Move a pair within its boundary band when its first route leaves no tuning room. */
export declare function repairPeripheralBusLengthsSteps(params: Params): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[] | null, void>;
export {};
