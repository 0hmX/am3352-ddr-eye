import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { FanoutRoutePlan, PreparedBus, RoutedSegment, RoutedVia } from "./types";
export interface MultiSegmentTuningWindow {
    before: RoutedSegment[];
    window: RoutedSegment[];
    after: RoutedSegment[];
    tuningLayer: string;
    addedVias: RoutedVia[];
}
/** Open a bounded, exterior tuning window without moving the original first via. */
export declare function getMultiSegmentTuningWindows(params: {
    plan: FanoutRoutePlan;
    bus: PreparedBus;
    inputSrj: SimpleRouteJson;
    plans: readonly FanoutRoutePlan[];
    layerNames: string[];
    clearance: number;
    consumeWork: () => void;
}): Generator<MultiSegmentTuningWindow>;
