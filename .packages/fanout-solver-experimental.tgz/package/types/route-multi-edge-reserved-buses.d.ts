import type { LayerReservedBusesParams, LayerReservedRoutingProgress } from "./route-layer-reserved-buses";
import type { FanoutRoutePlan } from "./types";
/** Route intact edge groups around one shared, validated source reservation.
 * Unfinished sources and packed boundary approaches remain hard throughout.
 * A group's new first vias become visible only after its complete lengths pass.
 */
export declare function routeMultiEdgeReservedBusesSteps(params: LayerReservedBusesParams): Generator<LayerReservedRoutingProgress, FanoutRoutePlan[] | null, unknown>;
