import type { RouteBusParams } from "./route-bus";
import type { PeripheralSourceEscape } from "./route-peripheral-source-escapes";
import type { RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { Bounds, FanoutRoutePlan } from "./types";
/** Use the annulus opposite the requested edge when its nearer source exits are blocked. */
export declare function routeOppositeBottomCrossbarBusSteps(params: RouteBusParams & {
    sourceEscapes: readonly PeripheralSourceEscape[];
    sourceBoundary: Bounds;
}): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[] | null, void>;
