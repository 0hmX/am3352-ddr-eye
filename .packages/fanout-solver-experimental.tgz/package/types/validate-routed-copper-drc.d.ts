import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { RoutedSegment } from "./types";
export type RoutedCopperDrcIssueCode = "unknown-trace-connection" | "unsupported-route-point" | "disconnected-trace" | "via-at-endpoint" | "trace-obstacle-clearance" | "via-obstacle-clearance" | "different-net-trace-clearance" | "different-net-trace-via-clearance" | "different-net-via-clearance";
export interface RoutedCopperDrcIssue {
    code: RoutedCopperDrcIssueCode;
    message: string;
    traceId: string;
    connectionName?: string;
    otherTraceId?: string;
    otherConnectionName?: string;
    layer?: string;
    obstacleId?: string;
}
export interface RoutedCopperDrcReport {
    valid: boolean;
    checkedTraceCount: number;
    checkedSegmentCount: number;
    checkedViaCount: number;
    issues: RoutedCopperDrcIssue[];
}
export declare function segmentIsLegalTerminalBodyEscape(params: {
    inputSrj: SimpleRouteJson;
    segment: RoutedSegment;
    bodyObstacle: SimpleRouteJson["obstacles"][number];
    connectionName: string;
}): boolean;
/**
 * Independently audits every emitted trace and via against the original SRJ
 * obstacle field and every other emitted net. This deliberately does not rely
 * on the solver's accepted route-plan objects.
 */
export declare function validateRoutedCopperDrc(params: {
    inputSrj: SimpleRouteJson;
    routedSrj: SimpleRouteJson;
    clearance: number;
    allowBlindAndBuriedVias?: boolean;
}): RoutedCopperDrcReport;
