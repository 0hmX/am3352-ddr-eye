import type { Obstacle, SimpleRouteConnection, SimpleRouteJson } from "@tscircuit/capacity-autorouter";
export declare function getConnectionNetKey(connection: SimpleRouteConnection): string;
export declare function connectionsShareElectricalNet(srj: SimpleRouteJson, firstConnectionName: string, secondConnectionName: string): boolean;
export declare function obstacleSharesElectricalNet(srj: SimpleRouteJson, obstacle: Obstacle, connectionName: string): boolean;
