import { type RouteBusParams } from "./route-bus";
import type { PeripheralSourceEscape } from "./route-peripheral-source-escapes";
import { type RouteViaMinimalWindingProgress } from "./route-via-minimal-winding";
import type { Bounds, FanoutRoutePlan } from "./types";
/** Choose unordered left source exits, then reconnect their original target order through a two-layer crossbar. */
export declare function routeAdaptiveLeftCrossbarBusSteps(params: RouteBusParams & {
    sourceEscapes: readonly PeripheralSourceEscape[];
    sourceBoundary: Bounds;
}): Generator<RouteViaMinimalWindingProgress, FanoutRoutePlan[] | null, void>;
