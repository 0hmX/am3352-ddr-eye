import type { SimpleRouteJson, SimplifiedPcbTrace } from "@tscircuit/capacity-autorouter";
import type { Point2D, RoutedSegment } from "./types";
export interface RoutedTraceVia {
    center: Point2D;
    diameter: number;
    spanLayers: string[];
}
export interface RoutedTraceCopper {
    trace: SimplifiedPcbTrace;
    connectionName: string;
    segments: RoutedSegment[];
    vias: RoutedTraceVia[];
}
export declare function getRoutedTraceCopper(srj: SimpleRouteJson, trace: SimplifiedPcbTrace, allowBlindAndBuriedVias?: boolean): RoutedTraceCopper;
export declare function getAllRoutedTraceCopper(srj: SimpleRouteJson, allowBlindAndBuriedVias?: boolean): RoutedTraceCopper[];
