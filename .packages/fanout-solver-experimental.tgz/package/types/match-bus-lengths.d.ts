import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import type { Bounds, FanoutRoutePlan, PreparedBus, RoutedSegment, RoutedVia } from "./types";
export declare function createPlanWithSegments(plan: FanoutRoutePlan, segments: RoutedSegment[], updateSourceEscapeCount?: boolean): FanoutRoutePlan | null;
/** New barrels must not bypass an earlier or later part of their own route. */
export declare function addedTuningViasAreSelfClear(plan: FanoutRoutePlan, addedVias: readonly RoutedVia[], clearance: number): boolean;
export declare function replacementCopperIsSelfClear(params: {
    plan: FanoutRoutePlan;
    segments: readonly RoutedSegment[];
    replacementStartIndex: number;
    replacementSegmentCount: number;
    clearance: number;
}): boolean;
/**
 * Adds straight/45-degree meanders after the dense component escape. Matching
 * is atomic: a constrained bus either satisfies its declared skew with the
 * complete fanout copper still clear, or the complete assignment is rejected.
 */
export interface MatchBusPlanLengthsParams {
    plans: readonly FanoutRoutePlan[];
    preparedBuses: readonly PreparedBus[];
    inputSrj: SimpleRouteJson;
    sharedBoundary: Bounds;
    clearance: number;
    allowBlindAndBuriedVias?: boolean;
    allowSameNetMerges?: boolean;
    /**
     * Allows tuning on target-layer copper inside the component pad envelope.
     * Intended only for coordinated dense routing whose complete copper is
     * revalidated and whose remaining dogbone capacity is checked atomically.
     */
    allowMatchingInsideDenseBounds?: boolean;
    /**
     * Tune existing source-layer copper after the first pad-escape segment and
     * before its fixed first via. Source counts are rebuilt; callers retaining
     * separate source-path maps must rebuild those maps from returned plans.
     * New meanders must also clear the source pad and all retained self copper.
     */
    allowSourcePrefixMatching?: boolean;
    /** Tune existing copper on originally permitted internal signal layers. */
    allowTransitLayerMatching?: boolean;
    /** Grow existing folds and distribute bounded additions across tuning sites. */
    allowDistributedMatching?: boolean;
    /** Add clear through vias to open a tuning window on another permitted signal layer. */
    allowAdditionalMatchingVias?: boolean;
    /**
     * Try exterior windows spanning multiple target segments, with two new
     * through-vias. This includes a permitted source-layer return after internal
     * travel and preserves the complete original source prefix and first via.
     * Callers may enable this after ordinary matching has exhausted its options.
     */
    allowMultiSegmentTuningWindows?: boolean;
    /** Allow a differential pair's longer lane to move aside before tuning its mate. */
    allowPairLaneSpreading?: boolean;
    /** Allow one unconstrained boundary lane to move around a tuning meander. */
    allowUnconstrainedLaneRerouting?: boolean;
    /**
     * Unfinished direct signal dogbones that may move to clear a tuning window.
     * Complete buses and plane drops are immutable. Callers must rebuild these
     * source reservations from returned plans only after all matching succeeds.
     */
    unroutedSourceBuses?: readonly PreparedBus[];
    /**
     * Rejects a geometrically clear candidate when it would make a caller-owned
     * downstream assignment (such as pending plane dogbones) infeasible.
     */
    candidatePlansAreFeasible?: (plans: readonly FanoutRoutePlan[]) => boolean;
    /**
     * Optional deterministic cap shared by the complete matching call and its
     * recursive repairs. Counts attempted meanders (including rejected ones),
     * multi-span states, lane-spreading attempts, and clearance validations.
     * Exhaustion returns the failed bus without committing partial tuning.
     */
    maximumWorkUnits?: number;
}
type MatchBusPlanLengthsResult = {
    plans: FanoutRoutePlan[];
    failedBus?: never;
} | {
    plans: null;
    failedBus: PreparedBus;
};
export declare function matchBusPlanLengths(params: MatchBusPlanLengthsParams): MatchBusPlanLengthsResult;
export {};
