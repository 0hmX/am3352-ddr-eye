import type { SimpleRouteJson } from "@tscircuit/capacity-autorouter";
import { BaseSolver } from "@tscircuit/solver-utils";
import { type GraphicsObject } from "graphics-debug";
import type { FanoutAttemptSummary, FanoutBorderDistribution, FanoutSolverOptions, FanoutSolverOutput, PreparedBus, SimpleRouteJsonWithFanoutPlanes } from "./types";
interface ResolvedFanoutConfig {
    traceWidth: number;
    viaDiameter: number;
    viaHoleDiameter: number;
    clearance: number;
    compactBusTracks: boolean;
    allowBlindAndBuriedVias: boolean;
    allowSameNetMerges: boolean;
    densePlaneReservationBusIds: readonly string[];
    denseUnrestrictedPlaneRoutingBusIds: readonly string[];
    singleLayerPushAndShove: boolean;
    singleLayerAdaptiveExits: boolean;
    borderDistribution: FanoutBorderDistribution;
    layerNames: string[];
    escapeLayers: string[];
    maxLayerCombinations: number;
    balanceLayerLoadByConnectionCount: boolean;
}
export declare function shouldDeferSingletonBoundaryViaReservation(boundaryBusConnectionCounts: readonly number[]): boolean;
export declare function getDenseSingletonDeferralCandidateCount(boundaryBusConnectionCounts: readonly number[]): number;
interface DenseSourceFieldBus {
    componentId: string;
    exitEdge?: PreparedBus["exitEdge"];
    allowedLayers?: readonly string[];
    routableEscapeLayers?: readonly string[];
    connections: readonly {
        sourcePoint: {
            x: number;
            y: number;
        };
    }[];
}
export declare function isDenseSingletonEmbeddedInMultiLayerWideBus(params: {
    singletonBus: DenseSourceFieldBus;
    singletonTargetLayer: string;
    wideBuses: readonly DenseSourceFieldBus[];
}): boolean;
export declare function getDenseLeadingCornerBandTargetTrackOffset(params: {
    leadingLaneCount: number;
    traceWidth: number;
    viaDiameter: number;
    clearance: number;
}): number;
export declare function shouldSearchAdditionalBoundaryRouteTopologies(params: {
    boundaryBusCount: number;
    connectionCount: number;
    rawSkew: number;
    maximumSkew: number;
}): boolean;
interface DenseSingletonBoundaryGeometryBus {
    busId: string;
    direction: PreparedBus["direction"];
    exitEdge?: PreparedBus["exitEdge"];
    preferredExit?: PreparedBus["preferredExit"];
    connections: readonly {
        sourcePoint: {
            x: number;
            y: number;
        };
        exitTargetPoint?: {
            x: number;
            y: number;
        };
    }[];
}
export declare function getDenseSingletonBoundaryGeometry(bus: DenseSingletonBoundaryGeometryBus): {
    isCorner: boolean;
    targetProjection: number;
};
export declare function compareDenseSingletonBoundaryDeferralPriority(first: DenseSingletonBoundaryGeometryBus, second: DenseSingletonBoundaryGeometryBus): number;
interface DensePairRoutingPriorityBus {
    componentId: string;
    exitEdge?: PreparedBus["exitEdge"];
    assignedLayer?: string;
    connections: readonly {
        sourceLayer: string;
        sourcePoint: {
            x: number;
            y: number;
        };
        exitTargetPoint?: {
            x: number;
            y: number;
            layer?: string;
        };
    }[];
}
export declare function getDenseBoundaryPairRoutingPriorityKeys(params: {
    boundaryBusCount: number;
    pairBuses: readonly DensePairRoutingPriorityBus[];
}): number[] | null;
export declare class FanoutSolver extends BaseSolver {
    readonly inputSrj: SimpleRouteJson;
    readonly options: FanoutSolverOptions;
    readonly preparedBuses: PreparedBus[];
    readonly attempts: FanoutAttemptSummary[];
    readonly layerAssignments: Array<Readonly<Record<string, string>>>;
    readonly config: ResolvedFanoutConfig;
    private readonly routingSrj;
    private readonly escapeLayersByBusId;
    private readonly boundaryBuses;
    private readonly fixedPlaneAssignments;
    private readonly evaluatedAssignmentKeys;
    private readonly queuedAssignmentKeys;
    private readonly assignmentRepairDepthByKey;
    private readonly pendingRepairAssignments;
    private readonly routeStaticClearanceCache;
    private readonly routingPrefixCache;
    private layerReservedRoutingEvaluated;
    private groupedBeamEvaluated;
    private routingInitialized;
    private nextCandidateLayerBusIndex;
    private nextAssignmentIndex;
    private nextGeneratedAssignmentIndex;
    private activeOperation;
    private inProgressPlans;
    private activeRoutingVisualization;
    private activeAdaptiveVisualization;
    private bestAttempt;
    private lengthMatchingFailure;
    private endpointCompletion;
    constructor(inputSrj: SimpleRouteJson, options?: FanoutSolverOptions);
    getSolverName(): string;
    /** Competing constrained buses need a shared source and layer reservation. */
    private shouldTryLayerReservedRouting;
    private evaluateLayerReservedRoutingSteps;
    private stepRoutingInitialization;
    private initializeRoutingSteps;
    private setInProgressPlans;
    private visualizeCurrentState;
    private visualizeWorkState;
    private visualizeBoundaryRoutingState;
    private visualizeAdaptiveRoutingState;
    private startOperation;
    private createWorkSolver;
    private routeBusAlternativesWorkSteps;
    private stepActiveOperation;
    private completeBestAttemptEndpoints;
    private getValidationBoundary;
    private validateCompletePlans;
    private matchCompletePlanLengths;
    private normalizeCompletePlanCorners;
    /** Reserve source escapes before joining complete buses around the package. */
    private routePeripheralMixedTerminationSteps;
    /**
     * Through-all source vias from a wide boundary bus can consume the only
     * legal dogbone channel for nearby plane pads. Conversely, routing hundreds
     * of singleton plane drops first can strand the boundary bus. Search a tiny
     * number of whole-bus boundary alternatives, then fill the remaining plane
     * dogbones. This is intentionally bounded independently of the number of
     * plane drops so dense power fields cannot explode the general beam search.
     */
    private routeDenseThroughAllMixedTerminationSteps;
    private evaluateAssignmentWithStrategySteps;
    private evaluateAssignmentSteps;
    /**
     * Search layer assignments and track alternatives together. The regular
     * assignment loop commits to one route per bus before the next bus is
     * considered, so a locally-valid track can still starve a later bus. A
     * bounded beam keeps several grouped-layer route prefixes alive. It also
     * evaluates multi-connection buses atomically, so one promising route for a
     * power or signal lane cannot starve a later bus before the solver explores
     * an alternate layer/track combination.
     */
    private evaluateGroupedBeamSteps;
    private evaluateGroupedBeamAlternativesSteps;
    private prioritizeFailedBusRepairs;
    private hasCompleteBestAttempt;
    private getCoordinatedAdditionalViaCount;
    private isAttemptBetter;
    private hasGloballyViaMinimalBestAttempt;
    private shouldEvaluateGroupedBeam;
    private commitGroupedBeamAttempt;
    private commitAssignmentAttempt;
    private getNextAssignment;
    private finishWithoutAnotherAssignment;
    _step(): void;
    computeProgress(): number;
    getConstructorParams(): [SimpleRouteJson, FanoutSolverOptions];
    getOutput(): FanoutSolverOutput;
    getOutputSimpleRouteJson(): SimpleRouteJsonWithFanoutPlanes;
    visualize(): GraphicsObject;
}
export {};
