export declare function getCopperLayerNames(layerCount: number): string[];
export declare function getLayerSpan(fromLayer: string, toLayer: string, layerNames: string[]): string[];
export declare function getViaSpanLayers(params: {
    fromLayer: string;
    toLayer: string;
    layerNames: string[];
    allowBlindAndBuriedVias: boolean;
}): string[];
export declare function getRouteViaSpanLayers(params: {
    fromLayer: string;
    toLayer: string;
    layers?: readonly string[];
    layerNames: string[];
    allowBlindAndBuriedVias: boolean;
}): string[];
export declare function generateLayerAssignments(params: {
    busIds: string[];
    layers: string[];
    layersByBusId?: Readonly<Record<string, readonly string[]>>;
    maxAssignments: number;
}): Array<Readonly<Record<string, string>>>;
