import type { Point2D, PreparedBus } from "./types";
/** Keep future approaches where an opposite pair lies directly behind a wide bus's exits. */
export declare function hasAlignedOppositeApproach(buses: readonly PreparedBus[], exits: ReadonlyMap<number, Point2D>): boolean;
