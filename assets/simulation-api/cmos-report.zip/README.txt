Recorded CMOS simulation report

Unzip this folder, then open results.html in a browser. Keep csv/ beside it.
The saved report works offline; no solvers or development tools are needed to view it.
Use Plots > Eye to view CMOS_DATA (RX) or CMOS_TX. The report also has Board, Tests, Results, CSV files, and Model tabs.
This bundle views a completed run; it does not rerun the simulation.

Circuit: examples/single-ended/index.circuit.tsx
Recorded UTC: 2026-10-18T13:56:37.957Z
Waveform rows: 129803; receiver eye: 26 complete windows; UI: 50 ns; gate: 200–1600 ns.
The unterminated fixture rings above its 3.3 V rail. These results do not establish interface safety or compliance.
Time columns are seconds and voltage columns are volts unless labeled otherwise.
Source receipt SHA-256: e04f9496fed35d307473ce4da65cfcd593d3ce9379f43b42f8f00d2e9dd33952
SHA256SUMS records each bundled report/CSV file. All report/CSV hashes match the source run receipt.
