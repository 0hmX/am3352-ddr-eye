Fresh historical DDR strip-model run, regenerated 2026-10-21.
Open results.html offline; keep csv/ alongside it.
Plots > DDR_SWITCHING > DQ0_RX > Eye: U3.E3 - U3.B1.
46 complete windows; 2.5 ns UI; 40-160 ns gate.
Switching eye voltage range: 0.21939993248038786-1.2970271364993355 V.

Reproduce from the repository after pnpm install and model/native setup:
PCB_SPICE_TOOLS=/tmp/pcbsim/tools/tools.json pnpm exec pcb-spice-pipeline examples/ddr-dq-strip/index.circuit.tsx --out /tmp/pcbsim/runs/ddr-dq-strip-2

run-summary.json records dependency pins, core build provenance, measured
quiet/switching values, original CSV hashes and the separate routed-copper
attempt's FastHenry failure. The pinned core tarball is temporarily included
in the repository because pkg.pr.new preview publication returned HTTP 404.

The new JLC pcb_stackup resolves the same copper z values as the historical
construction; switching waveform and eye CSVs are byte-identical to the old
report. Native solvers ran fresh; no solver result cache was used.
