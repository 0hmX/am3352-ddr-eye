Recorded AM3352 three-trace DDR report

Unzip and open results.html in a browser; keep csv/ beside it. No solver installation is required to view this saved run.
Plots > Experiment: DDR_SWITCHING > Probe: DQ0_RX > Eye shows the README's receiver eye.
The full report contains DDR_QUIET and DDR_SWITCHING, six probes per experiment, and four eyes.
Selected traces: DQ0, DQS, DQSn. Receiver: U3.E3 relative to U3.B1.
DQ0 eye: 46 windows; UI 2.5 ns; gate 40–160 ns. No artificial jitter is added.
Circuit: examples/ddr-dq/index.circuit.tsx. To run again: pnpm simulate:ddr-dq --open
Recorded UTC: 2026-10-18T14:02:10.607Z
Source receipt SHA-256: 08e012918f776d8b6e8bf847aab6995daf7e2a545e5249dce0dba8128019e4e8
Every report/CSV hash matches this recorded run. SHA256SUMS verifies the files.
These are finite deterministic transients of a reduced channel, not BER or compliance measurements.
